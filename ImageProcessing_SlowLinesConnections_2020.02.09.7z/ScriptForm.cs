﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageProcessing
{
    public partial class ScriptForm : Form
    {
        ScriptOutVal proc;

        internal ScriptForm(ScriptOutVal Proc)
        {
            proc = Proc;

            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            proc.CoreScript = textBox1.Text;
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            proc.CoreScript = textBox1.Text;
            e.Cancel = true;
            Hide();
            //base.OnClosing(e);
        }
    }
}
