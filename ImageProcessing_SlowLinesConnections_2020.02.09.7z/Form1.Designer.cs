﻿namespace ImageProcessing
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.plikToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sourceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.imageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.folderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resultBoxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mathToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.invertToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.safeAddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.safeSubtractToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.subtractToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.divideToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.multiplyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.minToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.maxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.meanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mean3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.circularAddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.squareRootToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aSinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.slopeTangensToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.roundTo0Or1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.convertersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aRGBToColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rGBToColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colorToARGBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hSBToColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colorToHSBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hCBToColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colorToHCBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.doubleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.opaqueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rGBToDoubleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.edgeColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.processToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mergeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paintToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trimValueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.functionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adjustToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.intensifyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inputToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.valueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.randomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.colorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.otherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scriptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.develToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.plikToolStripMenuItem,
            this.sourceToolStripMenuItem,
            this.resultBoxToolStripMenuItem,
            this.mathToolStripMenuItem,
            this.convertersToolStripMenuItem,
            this.processToolStripMenuItem,
            this.functionToolStripMenuItem,
            this.inputToolStripMenuItem,
            this.otherToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // plikToolStripMenuItem
            // 
            this.plikToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.openToolStripMenuItem,
            this.addToolStripMenuItem1,
            this.saveToolStripMenuItem,
            this.exportToolStripMenuItem});
            this.plikToolStripMenuItem.Name = "plikToolStripMenuItem";
            this.plikToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.plikToolStripMenuItem.Text = "File";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.newToolStripMenuItem.Text = "New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click_1);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // addToolStripMenuItem1
            // 
            this.addToolStripMenuItem1.Name = "addToolStripMenuItem1";
            this.addToolStripMenuItem1.Size = new System.Drawing.Size(108, 22);
            this.addToolStripMenuItem1.Text = "Add";
            this.addToolStripMenuItem1.Click += new System.EventHandler(this.addToolStripMenuItem1_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // exportToolStripMenuItem
            // 
            this.exportToolStripMenuItem.Name = "exportToolStripMenuItem";
            this.exportToolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.exportToolStripMenuItem.Text = "Export";
            this.exportToolStripMenuItem.Click += new System.EventHandler(this.exportToolStripMenuItem_Click);
            // 
            // sourceToolStripMenuItem
            // 
            this.sourceToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.imageToolStripMenuItem,
            this.folderToolStripMenuItem});
            this.sourceToolStripMenuItem.Name = "sourceToolStripMenuItem";
            this.sourceToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.sourceToolStripMenuItem.Text = "Source";
            this.sourceToolStripMenuItem.Click += new System.EventHandler(this.sourceToolStripMenuItem_Click);
            // 
            // imageToolStripMenuItem
            // 
            this.imageToolStripMenuItem.Name = "imageToolStripMenuItem";
            this.imageToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.imageToolStripMenuItem.Text = "Image";
            this.imageToolStripMenuItem.Click += new System.EventHandler(this.imageToolStripMenuItem_Click);
            // 
            // folderToolStripMenuItem
            // 
            this.folderToolStripMenuItem.Name = "folderToolStripMenuItem";
            this.folderToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.folderToolStripMenuItem.Text = "Folder";
            this.folderToolStripMenuItem.Click += new System.EventHandler(this.folderToolStripMenuItem_Click);
            // 
            // resultBoxToolStripMenuItem
            // 
            this.resultBoxToolStripMenuItem.Name = "resultBoxToolStripMenuItem";
            this.resultBoxToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.resultBoxToolStripMenuItem.Text = "Result";
            this.resultBoxToolStripMenuItem.Click += new System.EventHandler(this.resultBoxToolStripMenuItem_Click);
            // 
            // mathToolStripMenuItem
            // 
            this.mathToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.invertToolStripMenuItem,
            this.safeAddToolStripMenuItem,
            this.safeSubtractToolStripMenuItem,
            this.addToolStripMenuItem,
            this.subtractToolStripMenuItem,
            this.divideToolStripMenuItem,
            this.multiplyToolStripMenuItem,
            this.minToolStripMenuItem,
            this.maxToolStripMenuItem,
            this.meanToolStripMenuItem,
            this.mean3ToolStripMenuItem,
            this.circularAddToolStripMenuItem,
            this.squareRootToolStripMenuItem,
            this.sinToolStripMenuItem,
            this.aSinToolStripMenuItem,
            this.slopeTangensToolStripMenuItem,
            this.roundTo0Or1ToolStripMenuItem});
            this.mathToolStripMenuItem.Name = "mathToolStripMenuItem";
            this.mathToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.mathToolStripMenuItem.Text = "Math";
            // 
            // invertToolStripMenuItem
            // 
            this.invertToolStripMenuItem.Name = "invertToolStripMenuItem";
            this.invertToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.invertToolStripMenuItem.Text = "Invert";
            this.invertToolStripMenuItem.Click += new System.EventHandler(this.invertToolStripMenuItem_Click_1);
            // 
            // safeAddToolStripMenuItem
            // 
            this.safeAddToolStripMenuItem.Name = "safeAddToolStripMenuItem";
            this.safeAddToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.safeAddToolStripMenuItem.Text = "Safe Add";
            this.safeAddToolStripMenuItem.Click += new System.EventHandler(this.safeAddToolStripMenuItem_Click_1);
            // 
            // safeSubtractToolStripMenuItem
            // 
            this.safeSubtractToolStripMenuItem.Name = "safeSubtractToolStripMenuItem";
            this.safeSubtractToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.safeSubtractToolStripMenuItem.Text = "Safe Subtract";
            this.safeSubtractToolStripMenuItem.Click += new System.EventHandler(this.safeSubtractToolStripMenuItem_Click);
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.addToolStripMenuItem.Text = "Add";
            this.addToolStripMenuItem.Click += new System.EventHandler(this.addToolStripMenuItem_Click);
            // 
            // subtractToolStripMenuItem
            // 
            this.subtractToolStripMenuItem.Name = "subtractToolStripMenuItem";
            this.subtractToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.subtractToolStripMenuItem.Text = "Subtract";
            this.subtractToolStripMenuItem.Click += new System.EventHandler(this.subtractToolStripMenuItem_Click);
            // 
            // divideToolStripMenuItem
            // 
            this.divideToolStripMenuItem.Name = "divideToolStripMenuItem";
            this.divideToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.divideToolStripMenuItem.Text = "Divide";
            this.divideToolStripMenuItem.Click += new System.EventHandler(this.divideToolStripMenuItem_Click);
            // 
            // multiplyToolStripMenuItem
            // 
            this.multiplyToolStripMenuItem.Name = "multiplyToolStripMenuItem";
            this.multiplyToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.multiplyToolStripMenuItem.Text = "Multiply";
            this.multiplyToolStripMenuItem.Click += new System.EventHandler(this.multiplyToolStripMenuItem_Click);
            // 
            // minToolStripMenuItem
            // 
            this.minToolStripMenuItem.Name = "minToolStripMenuItem";
            this.minToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.minToolStripMenuItem.Text = "Min";
            this.minToolStripMenuItem.Click += new System.EventHandler(this.minToolStripMenuItem_Click);
            // 
            // maxToolStripMenuItem
            // 
            this.maxToolStripMenuItem.Name = "maxToolStripMenuItem";
            this.maxToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.maxToolStripMenuItem.Text = "Max";
            this.maxToolStripMenuItem.Click += new System.EventHandler(this.maxToolStripMenuItem_Click);
            // 
            // meanToolStripMenuItem
            // 
            this.meanToolStripMenuItem.Name = "meanToolStripMenuItem";
            this.meanToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.meanToolStripMenuItem.Text = "Mean";
            this.meanToolStripMenuItem.Click += new System.EventHandler(this.meanToolStripMenuItem_Click);
            // 
            // mean3ToolStripMenuItem
            // 
            this.mean3ToolStripMenuItem.Name = "mean3ToolStripMenuItem";
            this.mean3ToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.mean3ToolStripMenuItem.Text = "Mean3";
            this.mean3ToolStripMenuItem.Click += new System.EventHandler(this.mean3ToolStripMenuItem_Click);
            // 
            // circularAddToolStripMenuItem
            // 
            this.circularAddToolStripMenuItem.Name = "circularAddToolStripMenuItem";
            this.circularAddToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.circularAddToolStripMenuItem.Text = "Circular Add";
            this.circularAddToolStripMenuItem.Click += new System.EventHandler(this.circularAddToolStripMenuItem_Click);
            // 
            // squareRootToolStripMenuItem
            // 
            this.squareRootToolStripMenuItem.Name = "squareRootToolStripMenuItem";
            this.squareRootToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.squareRootToolStripMenuItem.Text = "Square Root";
            this.squareRootToolStripMenuItem.Click += new System.EventHandler(this.squareRootToolStripMenuItem_Click);
            // 
            // sinToolStripMenuItem
            // 
            this.sinToolStripMenuItem.Name = "sinToolStripMenuItem";
            this.sinToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.sinToolStripMenuItem.Text = "Sinus";
            this.sinToolStripMenuItem.Click += new System.EventHandler(this.sinToolStripMenuItem_Click);
            // 
            // aSinToolStripMenuItem
            // 
            this.aSinToolStripMenuItem.Name = "aSinToolStripMenuItem";
            this.aSinToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.aSinToolStripMenuItem.Text = "Arcus Sinus";
            this.aSinToolStripMenuItem.Click += new System.EventHandler(this.aSinToolStripMenuItem_Click);
            // 
            // slopeTangensToolStripMenuItem
            // 
            this.slopeTangensToolStripMenuItem.Name = "slopeTangensToolStripMenuItem";
            this.slopeTangensToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.slopeTangensToolStripMenuItem.Text = "Slope Tangens";
            this.slopeTangensToolStripMenuItem.Click += new System.EventHandler(this.slopeTangensToolStripMenuItem_Click);
            // 
            // roundTo0Or1ToolStripMenuItem
            // 
            this.roundTo0Or1ToolStripMenuItem.Name = "roundTo0Or1ToolStripMenuItem";
            this.roundTo0Or1ToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.roundTo0Or1ToolStripMenuItem.Text = "Round To 0 Or 1";
            this.roundTo0Or1ToolStripMenuItem.Click += new System.EventHandler(this.roundTo0Or1ToolStripMenuItem_Click);
            // 
            // convertersToolStripMenuItem
            // 
            this.convertersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aRGBToColorToolStripMenuItem,
            this.rGBToColorToolStripMenuItem,
            this.colorToARGBToolStripMenuItem,
            this.hSBToColorToolStripMenuItem,
            this.colorToHSBToolStripMenuItem,
            this.hCBToColorToolStripMenuItem,
            this.colorToHCBToolStripMenuItem,
            this.doubleToolStripMenuItem,
            this.opaqueToolStripMenuItem,
            this.rGBToDoubleToolStripMenuItem,
            this.edgeColorToolStripMenuItem});
            this.convertersToolStripMenuItem.Name = "convertersToolStripMenuItem";
            this.convertersToolStripMenuItem.Size = new System.Drawing.Size(76, 20);
            this.convertersToolStripMenuItem.Text = "Converters";
            // 
            // aRGBToColorToolStripMenuItem
            // 
            this.aRGBToColorToolStripMenuItem.Name = "aRGBToColorToolStripMenuItem";
            this.aRGBToColorToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.aRGBToColorToolStripMenuItem.Text = "ARGB To Color";
            this.aRGBToColorToolStripMenuItem.Click += new System.EventHandler(this.aRGBToColorToolStripMenuItem_Click);
            // 
            // rGBToColorToolStripMenuItem
            // 
            this.rGBToColorToolStripMenuItem.Name = "rGBToColorToolStripMenuItem";
            this.rGBToColorToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.rGBToColorToolStripMenuItem.Text = "RGB To Color";
            this.rGBToColorToolStripMenuItem.Click += new System.EventHandler(this.rGBToColorToolStripMenuItem_Click);
            // 
            // colorToARGBToolStripMenuItem
            // 
            this.colorToARGBToolStripMenuItem.Name = "colorToARGBToolStripMenuItem";
            this.colorToARGBToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.colorToARGBToolStripMenuItem.Text = "Color To ARGB";
            this.colorToARGBToolStripMenuItem.Click += new System.EventHandler(this.colorToARGBToolStripMenuItem_Click);
            // 
            // hSBToColorToolStripMenuItem
            // 
            this.hSBToColorToolStripMenuItem.Name = "hSBToColorToolStripMenuItem";
            this.hSBToColorToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.hSBToColorToolStripMenuItem.Text = "HSB To Color";
            this.hSBToColorToolStripMenuItem.Click += new System.EventHandler(this.hSBToColorToolStripMenuItem_Click);
            // 
            // colorToHSBToolStripMenuItem
            // 
            this.colorToHSBToolStripMenuItem.Name = "colorToHSBToolStripMenuItem";
            this.colorToHSBToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.colorToHSBToolStripMenuItem.Text = "Color To HSB";
            this.colorToHSBToolStripMenuItem.Click += new System.EventHandler(this.colorToHSBToolStripMenuItem_Click);
            // 
            // hCBToColorToolStripMenuItem
            // 
            this.hCBToColorToolStripMenuItem.Name = "hCBToColorToolStripMenuItem";
            this.hCBToColorToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.hCBToColorToolStripMenuItem.Text = "HCB To Color";
            this.hCBToColorToolStripMenuItem.Click += new System.EventHandler(this.hCBToColorToolStripMenuItem_Click);
            // 
            // colorToHCBToolStripMenuItem
            // 
            this.colorToHCBToolStripMenuItem.Name = "colorToHCBToolStripMenuItem";
            this.colorToHCBToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.colorToHCBToolStripMenuItem.Text = "Color To HCB";
            this.colorToHCBToolStripMenuItem.Click += new System.EventHandler(this.colorToHCBToolStripMenuItem_Click);
            // 
            // doubleToolStripMenuItem
            // 
            this.doubleToolStripMenuItem.Name = "doubleToolStripMenuItem";
            this.doubleToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.doubleToolStripMenuItem.Text = "Double To Grayscale";
            this.doubleToolStripMenuItem.Click += new System.EventHandler(this.doubleToolStripMenuItem_Click);
            // 
            // opaqueToolStripMenuItem
            // 
            this.opaqueToolStripMenuItem.Name = "opaqueToolStripMenuItem";
            this.opaqueToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.opaqueToolStripMenuItem.Text = "Opaque";
            this.opaqueToolStripMenuItem.Click += new System.EventHandler(this.opaqueToolStripMenuItem_Click);
            // 
            // rGBToDoubleToolStripMenuItem
            // 
            this.rGBToDoubleToolStripMenuItem.Name = "rGBToDoubleToolStripMenuItem";
            this.rGBToDoubleToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.rGBToDoubleToolStripMenuItem.Text = "RGB To Double";
            this.rGBToDoubleToolStripMenuItem.Click += new System.EventHandler(this.rGBToDoubleToolStripMenuItem_Click);
            // 
            // edgeColorToolStripMenuItem
            // 
            this.edgeColorToolStripMenuItem.Name = "edgeColorToolStripMenuItem";
            this.edgeColorToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.edgeColorToolStripMenuItem.Text = "Edge Color";
            this.edgeColorToolStripMenuItem.Click += new System.EventHandler(this.edgeColorToolStripMenuItem_Click);
            // 
            // processToolStripMenuItem
            // 
            this.processToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mergeToolStripMenuItem,
            this.paintToolStripMenuItem,
            this.trimValueToolStripMenuItem});
            this.processToolStripMenuItem.Name = "processToolStripMenuItem";
            this.processToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.processToolStripMenuItem.Text = "Process";
            // 
            // mergeToolStripMenuItem
            // 
            this.mergeToolStripMenuItem.Name = "mergeToolStripMenuItem";
            this.mergeToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.mergeToolStripMenuItem.Text = "Merge";
            this.mergeToolStripMenuItem.Click += new System.EventHandler(this.mergeToolStripMenuItem_Click);
            // 
            // paintToolStripMenuItem
            // 
            this.paintToolStripMenuItem.Name = "paintToolStripMenuItem";
            this.paintToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.paintToolStripMenuItem.Text = "Paint";
            this.paintToolStripMenuItem.Click += new System.EventHandler(this.paintToolStripMenuItem_Click);
            // 
            // trimValueToolStripMenuItem
            // 
            this.trimValueToolStripMenuItem.Name = "trimValueToolStripMenuItem";
            this.trimValueToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.trimValueToolStripMenuItem.Text = "Trim Value";
            this.trimValueToolStripMenuItem.Click += new System.EventHandler(this.trimValueToolStripMenuItem_Click);
            // 
            // functionToolStripMenuItem
            // 
            this.functionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adjustToolStripMenuItem,
            this.intensifyToolStripMenuItem});
            this.functionToolStripMenuItem.Name = "functionToolStripMenuItem";
            this.functionToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.functionToolStripMenuItem.Text = "Function";
            // 
            // adjustToolStripMenuItem
            // 
            this.adjustToolStripMenuItem.Name = "adjustToolStripMenuItem";
            this.adjustToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.adjustToolStripMenuItem.Text = "Adjust";
            this.adjustToolStripMenuItem.Click += new System.EventHandler(this.adjustToolStripMenuItem_Click_1);
            // 
            // intensifyToolStripMenuItem
            // 
            this.intensifyToolStripMenuItem.Name = "intensifyToolStripMenuItem";
            this.intensifyToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.intensifyToolStripMenuItem.Text = "Intensify";
            this.intensifyToolStripMenuItem.Click += new System.EventHandler(this.intensifyToolStripMenuItem_Click);
            // 
            // inputToolStripMenuItem
            // 
            this.inputToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.valueToolStripMenuItem,
            this.randomToolStripMenuItem,
            this.toolStripMenuItem2,
            this.colorToolStripMenuItem});
            this.inputToolStripMenuItem.Name = "inputToolStripMenuItem";
            this.inputToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.inputToolStripMenuItem.Text = "Input";
            // 
            // valueToolStripMenuItem
            // 
            this.valueToolStripMenuItem.Name = "valueToolStripMenuItem";
            this.valueToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.valueToolStripMenuItem.Text = "Value";
            this.valueToolStripMenuItem.Click += new System.EventHandler(this.valueToolStripMenuItem_Click);
            // 
            // randomToolStripMenuItem
            // 
            this.randomToolStripMenuItem.Name = "randomToolStripMenuItem";
            this.randomToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.randomToolStripMenuItem.Text = "Random";
            this.randomToolStripMenuItem.Click += new System.EventHandler(this.randomToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(119, 22);
            this.toolStripMenuItem2.Text = "0-10";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.Value0_10ToolStripMenuItem2_Click);
            // 
            // colorToolStripMenuItem
            // 
            this.colorToolStripMenuItem.Name = "colorToolStripMenuItem";
            this.colorToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.colorToolStripMenuItem.Text = "Color";
            this.colorToolStripMenuItem.Click += new System.EventHandler(this.colorToolStripMenuItem_Click);
            // 
            // otherToolStripMenuItem
            // 
            this.otherToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.resizeToolStripMenuItem,
            this.tileToolStripMenuItem,
            this.scriptToolStripMenuItem,
            this.develToolStripMenuItem});
            this.otherToolStripMenuItem.Name = "otherToolStripMenuItem";
            this.otherToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.otherToolStripMenuItem.Text = "Other";
            this.otherToolStripMenuItem.Click += new System.EventHandler(this.otherToolStripMenuItem_Click);
            // 
            // resizeToolStripMenuItem
            // 
            this.resizeToolStripMenuItem.Name = "resizeToolStripMenuItem";
            this.resizeToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.resizeToolStripMenuItem.Text = "Resize";
            this.resizeToolStripMenuItem.Click += new System.EventHandler(this.resizeToolStripMenuItem_Click);
            // 
            // scriptToolStripMenuItem
            // 
            this.scriptToolStripMenuItem.Name = "scriptToolStripMenuItem";
            this.scriptToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.scriptToolStripMenuItem.Text = "Script";
            this.scriptToolStripMenuItem.Click += new System.EventHandler(this.scriptToolStripMenuItem_Click);
            // 
            // develToolStripMenuItem
            // 
            this.develToolStripMenuItem.Name = "develToolStripMenuItem";
            this.develToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.develToolStripMenuItem.Text = "devel";
            this.develToolStripMenuItem.Click += new System.EventHandler(this.develToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Location = new System.Drawing.Point(0, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(800, 421);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.SizeChanged += new System.EventHandler(this.pictureBox1_SizeChanged);
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // tileToolStripMenuItem
            // 
            this.tileToolStripMenuItem.Name = "tileToolStripMenuItem";
            this.tileToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.tileToolStripMenuItem.Text = "Tile";
            this.tileToolStripMenuItem.Click += new System.EventHandler(this.tileToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Image Processing";
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.Form1_DragDrop);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.Form1_DragEnter);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem plikToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sourceToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem mathToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem convertersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aRGBToColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem invertToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem processToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mergeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem functionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adjustToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem safeAddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem safeSubtractToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem multiplyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem minToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem maxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem meanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inputToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem valueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem randomToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem opaqueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rGBToDoubleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem circularAddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mean3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem squareRootToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trimValueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem subtractToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem divideToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem rGBToColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hSBToColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aSinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem slopeTangensToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem roundTo0Or1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colorToHSBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem doubleToolStripMenuItem;
        private KKLib.ColorPicker colorPicker1;
        private System.Windows.Forms.ToolStripMenuItem colorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hCBToColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colorToHCBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem intensifyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resultBoxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem otherToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem imageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem folderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem develToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem edgeColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scriptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paintToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colorToARGBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tileToolStripMenuItem;
    }
}

