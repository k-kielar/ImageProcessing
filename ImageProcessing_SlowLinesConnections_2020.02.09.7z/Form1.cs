﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Numerics;
using KKLib;

namespace ImageProcessing
{
    public partial class Form1 : Form
    {
        Bitmap bmp;
        Graphics gr;
        Bitmap bmpDB;
        Graphics grDB;
        Bitmap bmpDL;
        Graphics grDL;
        Tuple<Point, Point>[] activeLines;

        List<IBox> boxes = new List<IBox>();
        List<BoxResult> boxsRes = new List<BoxResult>();
        Size size;
        List<Pair<Pin>> connections = new List<Pair<Pin>>();

        OpenFileDialog ofd = new OpenFileDialog();
        SaveFileDialog sfd = new SaveFileDialog();
        OpenFileDialog ofds = new OpenFileDialog();
        SaveFileDialog sfds = new SaveFileDialog();
        FolderBrowserDialog fbd = new FolderBrowserDialog();

        int lineWid = 3;
        int lineRectBuffer;
        int maxLineArea = 40 * 40;
        Pen penConnections = new Pen(Color.FromArgb(36, 185, 234), 3);
        Pen penDrag = new Pen(Color.FromArgb(13, 98, 125), 3);

        Point Start = new Point(200, 200);

        public static Form1 Frm;

        public Form1()
        {
            Frm = this;

            InitializeComponent();
            InitPBox();

            Redraw();

            ofd.InitialDirectory = @"D:\Projekty\Atlas\Atlas\bin\Debug";
            ofd.Filter = "Image Files|*.jpg;*.jpeg;*.png;";

            sfd.InitialDirectory = @"D:\Projekty\Atlas\Atlas\bin\Debug";
            sfd.Filter = "Png|*.png;";

            ofds.InitialDirectory = @"D:\Projekty\images\ImageProcessing";

            sfds.InitialDirectory = @"D:\Projekty\images\ImageProcessing";

            fbd.SelectedPath = @"D:\Pic";

            lineRectBuffer = lineWid / 2 + 2;
        }

        void Execute()
        {
            foreach (var br in boxsRes)
            {
                br.Update();
            }
            Redraw();
        }
        void Redraw()
        {
            gr.Clear(Color.White);

            foreach (var box in boxes)
            {
                box.Draw(gr);
            }

            foreach (var conn in connections)
            {
                var pa = conn.Item1.Box.Rect.Location + (Size)conn.Item1.P;
                var pb = conn.Item2.Box.Rect.Location + (Size)conn.Item2.P;
                gr.DrawLine(penConnections, pa, pb);
            }

            pictureBox1.Invalidate();
        }
        void RedrawStartMoving(IBox active)
        {
            grDB.Clear(Color.White);
            RedrawBoxes(grDB, active);
            gr.DrawImageUnscaled(bmpDB, 0, 0);
            grDL.Clear(Color.Transparent);
            RedrawLines(grDL, active);
            gr.DrawImageUnscaled(bmpDL, 0, 0);
            active.Draw(gr);

            activeLines = new Tuple<Point, Point>[active.pins[0].Length + active.pins[1].Length];
            foreach (var conn in connections)
            {
                var ba = conn.Item1.Box;
                var bb = conn.Item2.Box;
                Point pa, pb;
                int ord = 0;
                if (ba == active)
                {
                    pa = ba.Rect.Location + (Size)conn.Item1.P;
                    pb = bb.Rect.Location + (Size)conn.Item2.P;
                    ord = conn.Item1.Order;
                }
                else
                {
                    if (bb != active) continue;
                    pb = ba.Rect.Location + (Size)conn.Item1.P;
                    pa = bb.Rect.Location + (Size)conn.Item2.P;
                    ord = conn.Item2.Order;
                }
                activeLines[ord + active.pins[1].Length] = new Tuple<Point, Point>(pa, pb);
            }

            pictureBox1.Invalidate(active.Rect);
        }
        void RedrawUpdateMoving(IBox active, Point oldPos, Point newPos)
        {
            var siz = new Size(active.Rect.Size.Width + 1, active.Rect.Size.Height + 1);
            var oldRect = new Rectangle(oldPos, siz);
            var newRect = new Rectangle(newPos, siz);
            gr.DrawImage(bmpDB, oldRect, oldRect, GraphicsUnit.Pixel);

            var clearBr = new TextureBrush(bmpDB);
            var clearPen = new Pen(clearBr, 4);
            gr.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None;
            foreach (var item in activeLines)
            {
                if (item != null) ClearLine(item.Item1, item.Item2, clearPen);
            }
            gr.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            active.Draw(gr);
            gr.DrawImage(bmpDL, newRect, newRect, GraphicsUnit.Pixel);
            pictureBox1.Invalidate(oldRect);
            pictureBox1.Invalidate(newRect);

            int i = 0;
            int di = 1;
            for (int q = active.pins.Length - 1; q >= 0; q--)
            {
                var column = active.pins[q];
                for (int w = 0; w < column.Length; w++)
                {
                    if (activeLines[i] != null)
                    {
                        activeLines[i] = new Tuple<Point, Point>(active.Rect.Location + (Size)column[w].P, activeLines[i].Item2);
                    }
                    i += di;
                }
                i = activeLines.Length - 1;
                di = -1;
            }

            foreach (var item in activeLines)
            {
                if (item != null)
                {
                    gr.DrawLine(penConnections, item.Item1, item.Item2);
                    InvalidateLine(item.Item1, item.Item2);
                }
            }
        }
        void ClearLine(Point pa, Point pb)
        {
            foreach (var rect in LineRects(pa, pb))
            {
                
                gr.DrawImage(bmpDB, rect, rect, GraphicsUnit.Pixel);
                gr.DrawImage(bmpDL, rect, rect, GraphicsUnit.Pixel);
                pictureBox1.Invalidate(rect);
            }
        }
        void ClearLine(Point pa, Point pb, Pen pen)
        {
            gr.DrawLine(pen, pa, pb);
            var path = new GraphicsPath();
            path.AddLine(pa, pb);
            var reg = new Region(path);
            pictureBox1.Invalidate(reg);
            
        }
        void InvalidateLine(Point pa, Point pb)
        {
            var path = new GraphicsPath();
            path.AddLine(pa, pb);
            var reg = new Region(path);
            pictureBox1.Invalidate(reg);
            
            //foreach (var rect in LineRects(pa, pb))
            //{
            //    pictureBox1.Invalidate(rect);
            //}
        }
        IEnumerable<Rectangle> LineRects(Point pa, Point pb)
        {
            var n = (int)Math.Floor(Math.Sqrt(Math.Abs((pb.X - pa.X) * (pb.Y - pa.Y)) / maxLineArea)) + 1;
            var p2 = pa;
            float dx = (pb.X - pa.X) / n;
            float dy = (pb.Y - pa.Y) / n;
            var wid = (int)Math.Abs(Math.Ceiling(dx)) + 2 * lineRectBuffer;
            var hei = (int)Math.Abs(Math.Ceiling(dy)) + 2 * lineRectBuffer;
            for (int q = 1; q <= n; q++)
            {
                var p1 = p2;
                p2 = new Point((int)(pa.X + q * dx), (int)(pa.Y + q * dy));
                yield return new Rectangle(Math.Min(p1.X, p2.X) - lineRectBuffer, Math.Min(p1.Y, p2.Y) - lineRectBuffer, wid, hei);
            }
        }
        void RedrawBoxes(Graphics gra, IBox active = null)
        {
            foreach (var box in boxes)
            {
                if (box != active)
                {
                    box.Draw(gra);
                }
            }
        }
        void RedrawLines(Graphics gra, IBox active = null)
        {
            foreach (var conn in connections)
            {
                var ba = conn.Item1.Box;
                if (ba == active) continue;
                var bb = conn.Item2.Box;
                if (bb == active) continue;
                var pa = ba.Rect.Location + (Size)conn.Item1.P;
                var pb = bb.Rect.Location + (Size)conn.Item2.P;
                gra.DrawLine(penConnections, pa, pb);
            }
        }

        private void pictureBox1_SizeChanged(object sender, EventArgs e)
        {
            if (pictureBox1.Width > 0 && pictureBox1.Height > 0)
            {
                InitPBox();
                Redraw();
            }
        }
        void InitPBox()
        {
            if (gr != null)
            {
                gr.Dispose();
                gr = null;
                bmp.Dispose();
                bmp = null;
                grDB.Dispose();
                bmpDB.Dispose();
                grDL.Dispose();
                bmpDL.Dispose();
            }

            bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            gr = Graphics.FromImage(bmp);
            bmpDB = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            grDB = Graphics.FromImage(bmpDB);
            bmpDL = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            grDL = Graphics.FromImage(bmpDL);
            pictureBox1.Image = bmp;
        }

        Point? mclick;
        ActionResult res;
        IBox boxInUse;
        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            var p = e.Location;
            mclick = p;
            for (int w = boxes.Count - 1; w >= 0; w--)
            {
                var box = boxes[w];
                var rect = box.Rect;
                if (rect.Contains(p))
                {
                    //bring to front
                    int last = boxes.Count - 1;
                    var temp = boxes[last];
                    boxes[last] = box;
                    boxes[w] = temp;

                    p = p - (Size)rect.Location;
                    if (p.Y < IBox.BarHeight)
                    {
                        if (p.Y < IBox.CloseBoxSize && p.X > rect.Width - IBox.CloseBoxSize) res = ActionResult.Close;
                        else
                        {
                            res = ActionResult.Move;
                            //RedrawStartMoving(box);
                        }
                    }
                    else if (p.X > + rect.Width - IBox.ResizeBoxSize && p.Y > + rect.Height - IBox.ResizeBoxSize) res = ActionResult.Resize;
                    else
                    {
                        var pin = box.GetPin(p);
                        if (pin == null)
                        {
                            res = box.MouseDown(p);
                        }
                        else
                        {
                            res = ActionResult.DragStart;
                            for (int q = 0; q < connections.Count; q++)
                            {
                                var conn = connections[q];
                                if (pin == conn.Item1 || pin == conn.Item2)
                                {//unplug
                                    Pin pinStart;
                                    if (pin == conn.Item1) pinStart = conn.Item2;
                                    else pinStart = conn.Item1;
                                    boxInUse = pinStart.Box;
                                    mclick = pinStart.Box.Rect.Location + (Size)pinStart.P;
                                    Pin inputPin;
                                    if (pin.IsInput) inputPin = pin;
                                    else inputPin = pinStart;
                                    inputPin.Proc.Inputs[inputPin.Order] = null;
                                    connections.RemoveAt(q);
                                    Execute();
                                    pictureBox1_MouseMove(sender, e);
                                    return;
                                }
                            }
                        }
                    }
                    boxInUse = box;
                    break;
                }
            }
        }
        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            switch (res)
            {
                case ActionResult.None:
                    break;
                case ActionResult.Close:
                    var p = e.Location - (Size)boxInUse.Rect.Location;
                    if (p.X > boxInUse.Rect.Width - IBox.CloseBoxSize && p.Y < IBox.CloseBoxSize)
                    {
                        foreach (var conn in connections)
                        {
                            if (conn.Item1.Box == boxInUse || conn.Item2.Box == boxInUse) return;
                        }
                        boxes.Remove(boxInUse);
                        var br = boxInUse as BoxResult;
                        if (br != null) boxsRes.Remove(br);
                        boxInUse.Close();
                        Redraw();
                    }
                    break;
                case ActionResult.Move:
                    break;
                case ActionResult.Resize:
                    break;
                case ActionResult.Internal:
                    var res = boxInUse.MouseUp(e.Location - (Size)boxInUse.Rect.Location);
                    if (res == ActionResult.Execute) Execute();
                    break;
                case ActionResult.DragStart:
                    var loc = e.Location;
                    foreach (var box in boxes)
                    {
                        var rect = box.Rect;
                        if (rect.Contains(loc))
                        {
                            if (box != boxInUse)
                            {
                                Pin left, right;
                                var a = box.GetPin(loc - (Size)rect.Location);
                                if (a != null)
                                {
                                    var b = boxInUse.GetPin(mclick.Value - (Size)boxInUse.Rect.Location);
                                    if (a.Order < 0 != b.Order < 0)
                                    {
                                        if (a.Order < 0)
                                        {
                                            left = a;
                                            right = b;
                                        }
                                        else
                                        {
                                            left = b;
                                            right = a;
                                        }
                                        if (right.Proc.InputType[right.Order] == left.Proc.OutputType)
                                        {
                                            connections.Add(new Pair<Pin>(left, right));
                                            if (right.Proc.Inputs[right.Order] != null)
                                            {//unplug old
                                                for (int q = 0; q < connections.Count; q++)
                                                {
                                                    if (right == connections[q].Item2)
                                                    {
                                                        connections.RemoveAt(q);
                                                        break;
                                                    }
                                                }
                                            }
                                            right.Proc.Inputs[right.Order] = left.Proc;
                                            Execute();
                                            break;
                                        }
                                    }
                                }
                            }
                            break;
                        }
                    }
                    Redraw();
                    break;
                case ActionResult.DragEnd:
                    break;
                default:
                    break;
            }
            res = ActionResult.None;
        }
        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            switch (res)
            {
                case ActionResult.Move:
                    var p = e.Location;
                    var oldp = boxInUse.Rect.Location;
                    boxInUse.Rect.X += p.X - mclick.Value.X;
                    boxInUse.Rect.Y += p.Y - mclick.Value.Y;
                    mclick = p;
                    //RedrawUpdateMoving(boxInUse, oldp, boxInUse.Rect.Location);
                    Redraw();
                    break;
                case ActionResult.Resize:
                    break;
                case ActionResult.Internal:
                    boxInUse.MouseMove(e.Location - (Size)boxInUse.Rect.Location);
                    Redraw();
                    break;
                case ActionResult.DragStart:
                    Redraw();
                    gr.DrawLine(penDrag, mclick.Value, e.Location);
                    break;
                default:
                    break;
            }
        }

        void addSource(string imgFile, Point start)
        {
            var img = new Bitmap(imgFile);
            if (boxsRes.Count == 0)
            {
                size = img.Size;
                var br = new BoxResult(new Point(Start.X + 400, Start.Y), new Bitmap(img.Width, img.Height));
                boxsRes.Add(br);
                boxes.Add(br);
            }
            boxes.Add(new BoxSource(start, img));
            Redraw();
        }

        //MENU
        //File
        private void newToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            boxes.Clear();
            boxsRes.Clear();
            connections.Clear();
            Redraw();
        }
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (ofds.ShowDialog() == DialogResult.OK)
            {
                newToolStripMenuItem_Click_1(sender, e);
                AddSaved(ofds.FileName);
            }
        }
        private void addToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (ofds.ShowDialog() == DialogResult.OK)
            {
                AddSaved(ofds.FileName);
            }
        }
        void AddSaved(string path)
        {
            using (var imp = File.Open(path, FileMode.Open))
            {
                var bf = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                int bn0 = boxes.Count;
                int bn = (int)bf.Deserialize(imp);
                for (int q = 0; q < bn; q++)
                {
                    boxes.Add((IBox)bf.Deserialize(imp));
                }

                var pinPairs = (List<int>)bf.Deserialize(imp);
                for (int q = 0; q < pinPairs.Count; q += 4)
                {
                    var left = boxes[pinPairs[q] + bn0].pins[1][pinPairs[q + 1]];
                    var right = boxes[pinPairs[q + 2] + bn0].pins[0][pinPairs[q + 3]];
                    connections.Add(new Pair<Pin>(left, right));
                    right.Proc.Inputs[right.Order] = left.Proc;
                }
            }
            Redraw();
        }
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (sfds.ShowDialog() == DialogResult.OK)
            {
                var pinDets = new Dictionary<Pin, int[]>();
                foreach (var con in connections)
                {
                    if (!pinDets.ContainsKey(con.Item1)) pinDets.Add(con.Item1, null);
                    pinDets.Add(con.Item2, null);
                }

                using (var exp = File.Create(sfds.FileName))
                {
                    var bf = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

                    int bn = 0;
                    foreach (var box in boxes)
                    {
                        if (!(box is BoxImg)) bn++;
                    }
                    bf.Serialize(exp, bn);

                    bn = 0;
                    foreach (var box in boxes)
                    {
                        if (box is BoxImg) continue;

                        bf.Serialize(exp, box);

                        foreach (var pins in box.pins)
                        {
                            int pn = 0;
                            foreach (var pin in pins)
                            {
                                if (pinDets.ContainsKey(pin))
                                {
                                    pinDets[pin] = new int[] { bn, pn };
                                }
                                pn++;
                            }
                        }
                        bn++;
                    }

                    var pinPairs = new List<int>(connections.Count * 4);
                    for (int q = 0; q < connections.Count; q++)
                    {
                        var con = connections[q];
                        var a = pinDets[con.Item1];
                        var b = pinDets[con.Item2];
                        if (a != null && b != null)
                        {
                            pinPairs.AddRange(a);
                            pinPairs.AddRange(b);
                        }
                    }
                    bf.Serialize(exp, pinPairs);
                }
            }
        }
        private void exportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (boxRes != null)
            //{
            //    if (sfd.ShowDialog() == DialogResult.OK)
            //    {
            //        boxRes.Save(sfd.FileName);
            //    }
            //}
        }
        //Source
        private void sourceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }
        private void imageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                addSource(ofd.FileName, Start);
            }
        }
        private void folderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fbd.ShowDialog() == DialogResult.OK)
            {
                tryAddFolder(fbd.SelectedPath);
            }
        }
        void tryAddFolder(string folderPath)
        {
            var paths = new List<string>();
            var di = new DirectoryInfo(folderPath);
            foreach (var item in di.EnumerateFiles())
            {
                var end = item.Name.Substring(item.Name.Length - 4).ToLower();
                if (end == ".png" || end == ".bmp" || end == ".jpg")
                {
                    paths.Add(item.FullName);
                }
            }
            if (paths.Count > 0)
            {
                boxes.Add(new FolderSource(paths.ToArray()).GenerateBox(Start));
                Redraw();
            }
        }
        //Result
        private void resultBoxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Size siz;
            if (size.Width > 0 && size.Height > 0)
            {
                siz = size;
            }
            else
            {
                siz = new Size(100, 100);
            }
            var br = new BoxResult(Start, new Bitmap(siz.Width, siz.Height));
            boxsRes.Add(br);
            boxes.Add(br);
            Redraw();
        }
        //Math
        private void invertToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            boxes.Add(new Invert().GenerateBox(Start));
            Redraw();
        }
        private void safeAddToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            boxes.Add(new SafeAdd().GenerateBox(Start));
            Redraw();
        }
        private void safeSubtractToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new SafeSubtract().GenerateBox(Start));
            Redraw();
        }
        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new Add().GenerateBox(Start));
            Redraw();
        }
        private void subtractToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new Subtract().GenerateBox(Start));
            Redraw();
        }
        private void multiplyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new Multiply().GenerateBox(Start));
            Redraw();
        }
        private void divideToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new Divide().GenerateBox(Start));
            Redraw();
        }
        private void minToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new Min().GenerateBox(Start));
            Redraw();
        }
        private void maxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new Max().GenerateBox(Start));
            Redraw();
        }
        private void meanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new Mean().GenerateBox(Start));
            Redraw();
        }
        private void circularAddToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new CircularAdd().GenerateBox(Start));
            Redraw();
        }
        private void mean3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new Mean3().GenerateBox(Start));
            Redraw();
        }
        private void squareRootToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new SqRoot().GenerateBox(Start));
            Redraw();
        }
        private void sinToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new Sin().GenerateBox(Start));
            Redraw();
        }
        private void aSinToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new ASin().GenerateBox(Start));
            Redraw();
        }
        private void slopeTangensToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new SlopeTan().GenerateBox(Start));
            Redraw();
        }
        private void roundTo0Or1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new RoundTo01().GenerateBox(Start));
            Redraw();
        }
        //Converter
        private void aRGBToColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new ARGBToRawColor().GenerateBox(Start));
            Redraw();
        }
        private void rGBToColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new RGBToRawColor().GenerateBox(Start));
            Redraw();
        }
        private void colorToARGBToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new BoxColToARGB(Start));
            Redraw();
        }
        private void hSBToColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new HSBToRawColor().GenerateBox(Start));
            Redraw();
        }
        private void colorToHSBToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new BoxRGBToHSB(Start));
            Redraw();
        }
        private void hCBToColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new HCBToRawColor().GenerateBox(Start));
            Redraw();
        }
        private void colorToHCBToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new BoxRGBToHCB(Start));
            Redraw();
        }
        private void rGBToDoubleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new RGBToDouble().GenerateBox(Start));
            Redraw();
        }
        private void opaqueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new Opaque().GenerateBox(Start));
            Redraw();
        }
        private void doubleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new DoubleToGrayScale().GenerateBox(Start));
            Redraw();
        }
        private void edgeColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new ColorEdge().GenerateBox(Start));
            Redraw();
        }
        //Process
        private void mergeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new Merge().GenerateBox(Start));
            Redraw();
        }
        private void paintToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new Paint().GenerateBox(Start));
            Redraw();
        }
        private void trimValueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new Trim().GenerateBox(Start));
            Redraw();
        }
        //Function
        //sin
        //arcs
        private void adjustToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            boxes.Add(new BoxAdjust(Start, new Adjust(9)));
            Redraw();
        }
        private void intensifyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new Intensifier().GenerateBox(Start));
            Redraw();
        }
        //Input
        private void valueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new BoxValue(Start, new Value()));
            Redraw();
        }
        private void randomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new Rand().GenerateBox(Start));
            Redraw();
        }
        private void Value0_10ToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            boxes.Add(new BoxValue(Start, new Value(), 10));
            Redraw();
        }
        private void colorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new BoxColor(Start, new SingleColor(), this));
            Redraw();
        }
        //Other
        private void otherToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        private void resizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new Resizer().GenerateBox(Start));
            Redraw();
        }
        private void tileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new Tile().GenerateBox(Start));
            Redraw();
        }
        private void scriptToolStripMenuItem_Click(object sender, EventArgs e)
        {
            boxes.Add(new BoxScript(Start, new ScriptOutVal()));
            Redraw();
        }

        private void Form1_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop)) e.Effect = DragDropEffects.Copy;
        }
        private void Form1_DragDrop(object sender, DragEventArgs e)
        {
            string file = ((string[])e.Data.GetData(DataFormats.FileDrop))[0];
            var end = file.Substring(file.Length - 4).ToLower();
            if (end == ".png" || end == ".bmp" || end == ".jpg")
            {
                addSource(file, PointToClient(new Point(e.X, e.Y)) - (Size)pictureBox1.Location);
            }
            else
            {
                tryAddFolder(file);
            }
        }

        private void develToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var i = BinaryOps.TOPBITINDEX(4);
            MessageBox.Show(i.ToString());


            //var eng = IronPython.Hosting.Python.CreateEngine();
            //var scope = eng.CreateScope();
            //scope.SetVariable("v1", 12.0);
            //var fs = new float[] { 0.5f, 1, 3, 4.32f, 5, 6, 7, 8 };
            //var vv = new Vector<float>[] { new Vector<float>(fs), new Vector<float>(fs, 4) };
            //scope.SetVariable("vec", new Vector<float>(fs));
            //scope.SetVariable("vv", vv);
            //scope.SetVariable("fs", fs);
            //var scr = eng.CreateScriptSourceFromString("vv[0][0]=5");
            //scr.Execute(scope);
            //MessageBox.Show(vv[0][0].ToString());

            //var arr2 = (float[])scope.GetVariable("arr2");
            //var r = scope.GetVariable("r");
            //var d = (double)r;
            //MessageBox.Show(d.ToString());

            var rnd = new Random();
            //var fs = new float[] { 0, 0.25f, 0.5f, 0.75f, 1, 0.2f, 0.3f, 0.7f, 0.8f };
            //var v = new System.Numerics.Vector<float>(fs, 0);
            //var sins = HCBToRawColor.Sinus(v);
            //v = new System.Numerics.Vector<float>(fs, 4);
            //sins = HCBToRawColor.Sinus(v);
            //v = new System.Numerics.Vector<float>(fs, 5);
            //sins = HCBToRawColor.Sinus(v);

            //for (int q = 0; q < 1000; q++)
            //{
            //    var angl = (float)rnd.NextDouble();
            //    var aim = Math.Sin(angl * Math.PI * 2);
            //    var res = HCBToRawColor.Sinus(angl);
            //    var d = Math.Abs(aim - res);
            //    if (d > 0.001)
            //    {
            //        var r2 = HCBToRawColor.Sinus(angl);
            //    }
            //}

            //var vs = new float[10];
            //vs[1] = 1;
            //vs[2] = 0.5f;
            //for (int q = 0; q < 1000000; q++)
            //{
            //    for (int w = 3; w < vs.Length; w++)
            //    {
            //        vs[w] = (float)rnd.NextDouble();
            //    }
            //    //var col = new InternalColor(vs[rnd.Next(vs.Length)], vs[rnd.Next(vs.Length)], vs[rnd.Next(vs.Length)]);
            //    ////col = new InternalColor(0, 0, 0);
            //    //var s0 = col.HSB().Item2;
            //    //var s = col.Saturation();
            //    //var d = Math.Abs(s - s0);
            //    //if (d > 0.01 & (col.R != 1 && col.G != 1 && col.B != 1))
            //    //{
            //    //    var ms = s0.ToString() + Environment.NewLine + s.ToString();
            //    //    ms += Environment.NewLine + col.R.ToString() + Environment.NewLine + col.G.ToString() + Environment.NewLine + col.B.ToString();
            //    //    MessageBox.Show(ms);
            //    //    var s00 = col.HSB().Item2;
            //    //    var s1 = col.Saturation();
            //    //}
            //    //if (s < 0 || s > 1)
            //    //{
            //    //    MessageBox.Show(s.ToString());
            //    //}

            //    var h = vs[rnd.Next(vs.Length)];
            //    var c = vs[rnd.Next(vs.Length)];
            //    var b = vs[rnd.Next(vs.Length)];
            //    var col1 = InternalColor.FromHSB0(h, c, b);
            //    var col2 = InternalColor.FromHSB(h, c, b);
            //    //var col1 = InternalColor.FromHCB0(h, c, b);
            //    //var col2 = InternalColor.FromHCB(h, c, b);
            //    //var col3 = HCBToRawColor.FromHCB((float)h, (float)c, (float)b);
            //    //var col2 = new InternalColor(col3.Item1, col3.Item2, col3.Item3);
            //    var dr = col2.R - col1.R;
            //    var dg = col2.G - col1.G;
            //    var db = col2.B - col1.B;
            //    var d = Math.Sqrt(dr * dr + db * db + dg * dg);
            //    if (d > 0.001)
            //    {
            //        var col11 = InternalColor.FromHCB0(h, c, b);
            //        var col22 = InternalColor.FromHCB(h, c, b);
            //    }
            //    if (col2.R < 0 || col2.R > 1 || col2.G < 0 || col2.G > 1 || col2.B < 0 || col2.B > 1)
            //    {
            //        MessageBox.Show(col2.ToString());
            //    }
            //}

            //var inputs = new Point3D[]
            //{
            //    new Point3D(0, 0, 0),
            //    new Point3D(0, 0, 1),
            //    new Point3D(0, 1, 0),
            //    new Point3D(0, 1, 1),
            //    new Point3D(0, 1, 0.5),
            //};
            ////var rnd = new Random();
            //for (int q = 0; q < 100000; q++)
            //{
            //    //inputs = new Point3D[] { new Point3D(rnd.NextDouble(), rnd.NextDouble(), rnd.NextDouble()) };
            //    inputs = new Point3D[] { new Point3D(rnd.NextDouble(), 1, rnd.NextDouble()) };
            //    foreach (var p in inputs)
            //    {
            //        var r = InternalColor.FromHSB((float)p.X, (float)p.Y, (float)p.Z);
            //        //var rr = HCBToRawColor.FromHCB((float)p.X, (float)p.Y, (float)p.Z);
            //        //var r = new InternalColor(rr.Item1, rr.Item2, rr.Item3);
            //        if (r.R < 0 || r.R > 1 || r.G < 0 || r.G > 1 || r.B < 0 || r.B > 1)
            //        {
            //            var s = p.X.ToString() + " " + p.Y.ToString() + " " + p.Z.ToString() + Environment.NewLine + r.R.ToString() + " " + r.G.ToString() + " " + r.B.ToString();
            //            s += Environment.NewLine + new BinaryDouble(r.R).ToString() + " | " + new BinaryDouble(r.G).ToString() + " | " + new BinaryDouble(r.B).ToString();
            //            MessageBox.Show(s);
            //            //r = InternalColor.FromHCB(p.X, p.Y, p.Z);
            //            //rr = HCBToRawColor.FromHCB((float)p.X, (float)p.Y, (float)p.Z);
            //        }
            //    }
            //}

            
        }

    }

    [Serializable]
    class Pin
    {
        public readonly Point P;
        [NonSerialized]
        public IBox Box;
        public readonly int Order;
        public readonly IProcessor Proc;
        public bool IsInput
        {
            get { return Order >= 0; }
        }

        public Pin(Point p, IBox box, int order, IProcessor proc)
        {
            P = p;
            Box = box;
            Order = order;
            Proc = proc;
        }
    }

    enum ActionResult
    {
        None,
        Close,
        Move,
        Resize,
        Internal,
        DragStart,
        DragEnd,
        Execute,
    }

    unsafe class PixelerVectoric : Pixeler
    {
        //Vector4* ptrV;
        //int strideV;
        //int shift;
        int* ptr0;

        public PixelerVectoric(Bitmap BMP) : base(BMP)
        {
            //ptrV = (Vector4*)raw.Scan0;
            //strideV = raw.Stride / 4 / Vector<int>.Count;
            //shift = BinaryOps.TOPBITINDEX((byte)Vector<float>.Count);
            ptr0 = (int*)raw.Scan0;
        }

        public void SetVector(int x, int y, Vector4 col)
        {
            ((Vector4*)(ptr0 + y * stride + x))[0] = col;
            //ptrV[y * strideV + (x >> shift)] = col;
        }
        public Vector4 GetVector(int x, int y)
        {
            return ((Vector4*)(ptr0 + y * stride + x))[0];
            //return ptrV[y * strideV + (x >> shift)];
        }
    }

}
