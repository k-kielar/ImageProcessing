﻿//#define BYTECOLOR

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using System.Text;
using System.Numerics;
using Microsoft.Scripting.Hosting;
using KKLib;

namespace ImageProcessing
{
    struct InternalColor
    {
        const double I = 0.999999999;
        const double D = 255 - I;

#if BYTECOLOR
        RawColor V;
        public double A { get { return Byte2Dbl(V.A); } }
        public double R { get { return Byte2Dbl(V.R); } }
        public double G { get { return Byte2Dbl(V.G); } }
        public double B { get { return Byte2Dbl(V.B); } }

        public InternalColor(double a, double r, double g, double b)
        {
            V = new RawColor(Dbl2Byte(a), Dbl2Byte(r), Dbl2Byte(g), Dbl2Byte(b));
        }
        public InternalColor(double r, double g, double b)
        {
            V = new RawColor(Dbl2Byte(r), Dbl2Byte(g), Dbl2Byte(b));
        }
        InternalColor(RawColor v)
        {
            V = v;
        }

        public Tripl<double> HSB()
        {
            var ret = V.HSB();
            return new Tripl<double>(ret.Item1, ret.Item2, ret.Item3);
        }
        public Tripl<double> HCB()
        {
            var ret = V.HCB();
            return new Tripl<double>(ret.Item1, ret.Item2, ret.Item3);
        }

        public static InternalColor FromHSB(double h, double s, double b)
        {
            return RawColor.FromHSB((float)h, (float)s, (float)b);
        }
        public static InternalColor FromHCB(double h, double c, double b)
        {
            return RawColor.FromHCB((float)h, (float)c, (float)b);
        }

        public static implicit operator InternalColor(RawColor rc)
        {
            return new InternalColor(rc);
        }
        public static implicit operator RawColor(InternalColor rc)
        {
            return rc.V;
        }
#else
        static readonly Point3D pBlack = new Point3D();
        static readonly Point3D pWhite = new Point3D(1, 1, 1);
        static readonly Point3D pDirX = new Point3D(0.5, -0.25, -0.25);
        static readonly Point3D pDirY = new Point3D(0, 0.5, -0.5);
        static readonly KKLib.Plane PlaneB = new KKLib.Plane(new Point3D(1, 0, 0), new Point3D(0, 1, 0), new Point3D(0, 0, 1)).Parallel(pBlack);
        static readonly KKLib.Plane PlaneX = new KKLib.Plane(pBlack, pWhite, new Point3D(0.5, 0, 1));
        static readonly KKLib.Plane PlaneY = new KKLib.Plane(pBlack, pWhite, new Point3D(1, 0, 0));
        const float From01ToRad = (float)(Math.PI * 2);
        const float RadTo01 = (float)(1 / From01ToRad);
        static readonly double SQRT3 = Math.Sqrt(3);
        static readonly float _SQRT3 = (float)(1 / Math.Sqrt(3));
        static readonly double MaxRad = Math.Sqrt(6.0) / 3;
        static readonly float maxRad = (float)MaxRad;
        static readonly double MaxRadHalf = MaxRad * 0.5;
        static readonly double MaxRadHalfNeg = MaxRad * -0.5;
        static readonly double MaxRadQuartNeg = MaxRad * -0.25;
        const float LXX = (float)(2.0 / 3);
        const float LXYZ = (float)(-1.0 / 3);
        const float LYYZ = (float)(0.5773502691896257);
        static KKLib.Plane[] cube;
        const float DIV = 1.0f / 255.0f;
        const float If = 0.9999999f;
        const float K = 255 - If;
        const float THIRD = 1.0f / 3;

        public float A;
        public float R;
        public float G;
        public float B;

        static InternalColor()
        {
            var p000 = new Point3D(0, 0, 0);
            var p001 = new Point3D(0, 0, 1);
            var p011 = new Point3D(0, 1, 1);
            var p100 = new Point3D(1, 0, 0);
            var p110 = new Point3D(1, 1, 0);
            var p111 = new Point3D(1, 1, 1);
            cube = new KKLib.Plane[]
            {
                new KKLib.Plane(p000, p100, p110),
                new KKLib.Plane(p000, p100, p001),
                new KKLib.Plane(p000, p001, p011),
                new KKLib.Plane(p100, p110, p111),
                new KKLib.Plane(p110, p011, p111),
                new KKLib.Plane(p001, p011, p111),
            };
        }

        public InternalColor(float a, float r, float g, float b)
        {
            A = a;
            R = r;
            G = g;
            B = b;
        }
        public InternalColor(float r, float g, float b)
        {
            A = 1;
            R = r;
            G = g;
            B = b;
        }

        public static byte Flt2Byte(float d)
        {
            return (byte)(d * K + If);
        }
        public static float Byte2Flt(byte b)
        {
            return b * DIV;
        }

        public static byte Dbl2Byte(double d)
        {
            return (byte)(d * D + I);
        }
        public static double Byte2Dbl(byte b)
        {
            return b / 255.0;
        }


        public Tripl<float> HSB()
        {
            var ret = new Tripl<float>();
            var rgb = new Point3D(R, G, B);
            var Bright = (float)PlaneB.Distance(rgb);
            var mid = Mth3D.OnLine(pBlack, pWhite, Bright);
            if (rgb != mid)
            {
                var x = PlaneX.SignedDistance(rgb);
                var y = PlaneY.SignedDistance(rgb);
                ret.Item1 = (float)(RadTo01 * Mth.Azimuth(x, y));
                var l = new Line3D(mid, rgb);
                double dmin = double.PositiveInfinity;
                Point3D pmin = pBlack;
                for (int q = 0; q < cube.Length; q++)
                {
                    var i = cube[q].Intersection(l);
                    if (((mid.X != rgb.X) && (i.X > mid.X == rgb.X > mid.X)) || (i.Y > mid.Y == rgb.Y > mid.Y))
                    {
                        var d = Mth3D.DSq(i, mid);
                        if (d < dmin)
                        {
                            dmin = d;
                            pmin = i;
                        }
                    }
                }
                ret.Item2 = (float)(Mth3D.Dist(mid, rgb) / Mth3D.Dist(mid, pmin));
            }

            ret.Item3 = Bright * _SQRT3;
            return ret;
        }
        public float Saturation()
        {
            var Bri = (R + G + B) * THIRD;

            var vx = R - Bri;
            var vy = G - Bri;
            var vz = B - Bri;

            var sx = (float)Math.Sign(vx);
            var sy = (float)Math.Sign(vy);
            var sz = (float)Math.Sign(vz);
            var maxx = (sx + 1) * 0.5f - sx * Bri;
            var maxy = (sy + 1) * 0.5f - sy * Bri;
            var maxz = (sz + 1) * 0.5f - sz * Bri;

            var kx = Math.Abs(vx) / maxx;
            var ky = Math.Abs(vy) / maxy;
            var kz = Math.Abs(vz) / maxz;

            var k = Math.Max(kx, Math.Max(ky, kz));
            return k;
        }

        public static InternalColor FromHSB0(double H, double S, double B)
        {
            var mid = Mth3D.OnLine(pBlack, pWhite, B * SQRT3);

            if (B != 0 && B != 1 && S != 0)
            {
                var a = Mth.Polar(new PointD(), From01ToRad * H, 2);
                var vx = Mth3D.OnLine(pBlack, pDirX, a.X);
                var vy = Mth3D.OnLine(pBlack, pDirY, a.Y);

                var dir = mid + vx + vy;
                var lDir = new Line3D(mid, dir);
                double dmin = double.PositiveInfinity;
                Point3D pmin = pBlack;
                for (int q = 0; q < cube.Length; q++)
                {
                    var i = cube[q].Intersection(lDir);
                    if ((i.X > mid.X == dir.X > i.X) || (i.Y > mid.Y == dir.Y > i.Y))
                    {
                        var d = Mth3D.DSq(i, mid);
                        if (d < dmin)
                        {
                            dmin = d;
                            pmin = i;
                        }
                    }
                }
                if (mid != pmin) mid = Mth3D.OnLine(mid, pmin, S * Mth3D.Dist(mid, pmin));
            }

            return new InternalColor((float)mid.X, (float)mid.Y, (float)mid.Z);
        }
        public static InternalColor FromHSB(float H, float S, float B)
        {
            var dx = (float)Math.Cos(From01ToRad * H);
            var dy = Math.Sign(0.5f - H) * (float)Math.Sqrt(1 - dx * dx);
            dx *= maxRad;
            dy = dy * maxRad * LYYZ;
            var vx = dx * LXX;
            var vy = dx * LXYZ + dy;
            var vz = dx * LXYZ - dy;

            var sx = (float)Math.Sign(vx);
            var sy = (float)Math.Sign(vy);
            var sz = (float)Math.Sign(vz);
            var maxx = (sx * sx + sx) * 0.5f - sx * B;
            var maxy = (sy * sy + sy) * 0.5f - sy * B;
            var maxz = (sz * sz + sz) * 0.5f - sz * B;

            var kx = Math.Abs(maxx / vx);
            var ky = Math.Abs(maxy / vy);
            var kz = Math.Abs(maxz / vz);
            float km, kd;
            if (kx < ky)
            {
                if (kx < kz)
                {
                    km = maxx;
                    kd = vx;
                }
                else
                {
                    km = maxz;
                    kd = vz;
                }
            }
            else
            {
                if (ky < kz)
                {
                    km = maxy;
                    kd = vy;
                }
                else
                {
                    km = maxz;
                    kd = vz;
                }
            }

            kd = Math.Abs(kd);
            return new InternalColor(B + S * vx / kd * km, B + S * vy / kd * km, B + S * vz / kd * km);
        }
        public static InternalColor FromHCB0(float H, float C, float B)
        {
            var mid = Mth3D.OnLine(pBlack, pWhite, B * SQRT3);

            if (B != 0 && B != 1 && C != 0)
            {
                var a = Mth.Polar(new PointD(), H * Math.PI * 2, 2);
                var vx = Mth3D.OnLine(pBlack, pDirX, a.X);
                var vy = Mth3D.OnLine(pBlack, pDirY, a.Y);

                var dir = mid + vx + vy;
                var lDir = new Line3D(mid, dir);
                double dmin = double.PositiveInfinity;
                Point3D pmin = pBlack;
                for (int q = 0; q < cube.Length; q++)
                {
                    var i = cube[q].Intersection(lDir);
                    if ((i.X > mid.X == dir.X > i.X) || (i.Y > mid.Y == dir.Y > i.Y))
                    {
                        var d = Mth3D.DSq(i, mid);
                        if (d < dmin)
                        {
                            dmin = d;
                            pmin = i;
                        }
                    }
                }
                C *= maxRad;
                var rad = Mth3D.Dist(mid, pmin);
                if (C > rad)
                {
                    mid = pmin;
                }
                else
                {
                    if (mid != pmin) mid = Mth3D.OnLine(mid, pmin, C);
                }
            }

            return new InternalColor((float)mid.X, (float)mid.Y, (float)mid.Z);
        }
        public static InternalColor FromHCB(float H, float C, float B)
        {
            var dx = (float)Math.Cos(From01ToRad * H);
            var dy = Math.Sign(0.5f - H) * (float)Math.Sqrt(1 - dx * dx);
            dx *= C;
            dy = dy * C * LYYZ;
            var vx = dx * LXX;
            var vy = dx * LXYZ + dy;
            var vz = dx * LXYZ - dy;

            var sx = (float)Math.Sign(vx);
            var sy = (float)Math.Sign(vy);
            var sz = (float)Math.Sign(vz);
            var maxx = (sx * sx + sx) * 0.5f - sx * B;
            var maxy = (sy * sy + sy) * 0.5f - sy * B;
            var maxz = (sz * sz + sz) * 0.5f - sz * B;

            var kx = Math.Abs(maxx / vx);
            var ky = Math.Abs(maxy / vy);
            var kz = Math.Abs(maxz / vz);
            var km = 1.0f;
            var kd = 1.0f;
            if (kx < ky)
            {
                if (kx < kz)
                {
                    if (kx < 1)
                    {
                        km = maxx;
                        kd = vx;
                    }
                }
                else
                {
                    if (kz < 1)
                    {
                        km = maxz;
                        kd = vz;
                    }
                }
            }
            else
            {
                if (ky < kz)
                {
                    if (ky < 1)
                    {
                        km = maxy;
                        kd = vy;
                    }
                }
                else
                {
                    if (kz < 1)
                    {
                        km = maxz;
                        kd = vz;
                    }
                }
            }
            
            kd = Math.Abs(kd);
            return new InternalColor(B + vx / kd * km, B + vy / kd * km, B + vz / kd * km);
        }

        public static implicit operator InternalColor(RawColor rc)
        {
            return new InternalColor(Byte2Flt(rc.A), Byte2Flt(rc.R), Byte2Flt(rc.G), Byte2Flt(rc.B));
        }
        public static implicit operator RawColor(InternalColor ic)
        {
            return new RawColor(Flt2Byte(ic.A), Flt2Byte(ic.R), Flt2Byte(ic.G), Flt2Byte(ic.B));
        }
#endif
    }
    class VectorColor
    {
        const float DIV = 1.0f / 255.0f;
        public const float I = 0.9999999f;
        public const float K = 255 - I;
        static readonly Vector<float> VDIV;
        static readonly Vector<float> VI;
        static readonly Vector<float> VK;
        public static readonly Vector<float> VONE = Vector<float>.One;
        public static readonly Vector<float> VZERO = Vector<float>.Zero;
        public static readonly Vector<float> VHALF;
        public static readonly Vector<float> VTHIRD;
        public static readonly Vector<float> VTWO;
        public static readonly Vector<float> VPI;
        public static readonly Vector<float> VPI2;
        public static readonly Vector<float> VPIHALF;
        public static readonly int Count = Vector<float>.Count;

        static VectorColor()
        {
            VDIV = new Vector<float>(DIV);
            VI = new Vector<float>(I);
            VK = new Vector<float>(K);
            VHALF = new Vector<float>(0.5f);
            VTHIRD = new Vector<float>(1.0f / 3);
            VTWO = new Vector<float>(2);
            VPI = new Vector<float>((float)Math.PI);
            VPI2 = new Vector<float>((float)Math.PI * 2);
            VPIHALF = new Vector<float>((float)Math.PI * 0.5f);
        }

        public Vector<float> As;
        public Vector<float> Rs;
        public Vector<float> Gs;
        public Vector<float> Bs;

        public VectorColor(Vector<float> als, Vector<float> rs, Vector<float> gs, Vector<float> bs)
        {
            As = als;
            Rs = rs;
            Gs = gs;
            Bs = bs;
        }

        public void RescaleToByte()
        {
            As = Flt2Byte(As);
            Rs = Flt2Byte(Rs);
            Gs = Flt2Byte(Gs);
            Bs = Flt2Byte(Bs);
        }

        public static Vector<float> Flt2Byte(Vector<float> vs)
        {
            return vs * VK + VI;
        }
        public static Vector<float> Byte2Flt(Vector<float> vs)
        {
            return vs * VDIV;
        }
    }

    [Serializable]
    class IProcessor
    {
        public const double MAXVAL = 255.0;
        protected static readonly Type TDbl = typeof(float);
        protected static readonly Type TRC = typeof(InternalColor);

        public Type[] InputType;
        public Type OutputType;
        [NonSerialized]
        public IProcessor[] Inputs;
        [NonSerialized]
        int[] lastXs;
        [NonSerialized]
        Vector<float>[] lastVals;
        [NonSerialized]
        VectorColor[] lastCols;

        public IProcessor()
        {
            InitLasts();
        }
        void InitLasts()
        {
            lastVals = new Vector<float>[BoxResult.THREADN];
            lastCols = new VectorColor[BoxResult.THREADN];
            lastXs = new int[BoxResult.THREADN];
            for (int q = 0; q < lastXs.Length; q++)
            {
                lastXs[q] = -1;
            }
        }

        public virtual float Evaluate(Point p)
        {
            
            return 0;
        }
        public virtual InternalColor EvaluateC(Point p)
        {
            return new InternalColor();
        }
        public virtual Vector<float> Evaluate(int x, int y, int th)
        {
            var ret = new float[Vector<float>.Count];
            for (int q = 0; q < ret.Length; q++)
            {
                ret[q] = (float)Evaluate(new Point(x + q, y));
            }
            return new Vector<float>(ret);
        }
        public Vector<float> Evaluatev(int x, int y, int th)
        {
            if (lastXs[th] == x)
            {
                return lastVals[th];
            }
            else
            {
                var ret = Evaluate(x, y, th);
                lastXs[th] = x;
                lastVals[th] = ret;
                return ret;
            }
        }
        public virtual VectorColor EvaluateC(int x, int y, int th)
        {
            var al = new float[Vector<float>.Count];
            var re = new float[Vector<float>.Count];
            var gr = new float[Vector<float>.Count];
            var bl = new float[Vector<float>.Count];
            for (int q = 0; q < Vector<float>.Count; q++)
            {
                var v = EvaluateC(new Point(x + q, y));
                al[q] = (float)v.A;
                re[q] = (float)v.R;
                gr[q] = (float)v.G;
                bl[q] = (float)v.B;
            }
            return new VectorColor(new Vector<float>(al), new Vector<float>(re), new Vector<float>(gr), new Vector<float>(bl));
        }
        public VectorColor EvaluateCv(int x, int y, int th)
        {
            if (lastXs[th] == x)
            {
                return lastCols[th];
            }
            else
            {
                var ret = EvaluateC(x, y, th);
                lastXs[th] = x;
                lastCols[th] = ret;
                return ret;
            }
        }
        public virtual bool CanEvaluate()
        {
            for (int q = 0; q < Inputs.Length; q++)
            {
                var inp = Inputs[q];
                if (inp == null) return false;
                if (!inp.CanEvaluate()) return false;
            }
            return true;
        }
        public virtual Size GetSize()
        {
            var ret = new Size(int.MaxValue, int.MaxValue);
            for (int q = 0; q < Inputs.Length; q++)
            {
                var s = Inputs[q].GetSize();
                if (s.Width < ret.Width) ret.Width = s.Width;
                if (s.Height < ret.Height) ret.Height = s.Height;
            }
            return ret;
        }

        [OnDeserialized]
        private void OnDeserialized(StreamingContext context)
        {
            Inputs = new IProcessor[InputType.Length];
            InitLasts();
        }
    }
    [Serializable]
    class ImgSource : IProcessor, IDisposable
    {
        public Bitmap bmp;
        PixelerVectoric pxlr;

        public ImgSource(Bitmap Bmp)
        {
            bmp = Bmp;
            pxlr = new PixelerVectoric(bmp);
            OutputType = TRC;
            Inputs = new IProcessor[0];
        }

        public override InternalColor EvaluateC(Point p)
        {
            return pxlr.GetPixel(p.X, p.Y);
        }
        //public override VectorColor EvaluateC(int x, int y, int th)
        //{
        //    var al = new float[Vector<float>.Count];
        //    var re = new float[Vector<float>.Count];
        //    var gr = new float[Vector<float>.Count];
        //    var bl = new float[Vector<float>.Count];
        //    for (int q = 0; q < Vector<float>.Count; q++)
        //    {
        //        var pix = pxlr.GetPixel(x + q, y);
        //        al[q] = pix.A;
        //        re[q] = pix.R;
        //        gr[q] = pix.G;
        //        bl[q] = pix.B;
        //    }
        //    var a = VectorColor.Byte2Flt(new Vector<float>(al));
        //    var r = VectorColor.Byte2Flt(new Vector<float>(re));
        //    var g = VectorColor.Byte2Flt(new Vector<float>(gr));
        //    var b = VectorColor.Byte2Flt(new Vector<float>(bl));
        //    return new VectorColor(a, r, g, b);
        //}

        static readonly Vector<float> bdiv = new Vector<float>((float)(1.0 / 0xff));
        static readonly Vector<float> gdiv = new Vector<float>((float)(1.0 / 0xff00));
        static readonly Vector<float> rdiv = new Vector<float>((float)(1.0 / 0xff0000));
        static readonly Vector<float> adiv = new Vector<float>((float)(1.0 / 0xff000000));
        public override VectorColor EvaluateC(int x, int y, int th)
        {
            VecStruct vstr = new VecStruct();
            vstr.v4 = pxlr.GetVector(x, y);
            var va = Vector.ConvertToSingle(vstr.vui & MthVector.MASK_ALPHA) * adiv;
            var vr = Vector.ConvertToSingle(vstr.vui & MthVector.MASK_RED) * rdiv;
            var vg = Vector.ConvertToSingle(vstr.vui & MthVector.MASK_GREEN) * gdiv;
            var vb = Vector.ConvertToSingle(vstr.vui & MthVector.MASK_BLUE) * bdiv;
            return new VectorColor(va, vr, vg, vb);
        }

        public override bool CanEvaluate()
        {
            return true;
        }
        public override Size GetSize()
        {
            return bmp.Size;
        }

        public void Dispose()
        {
            pxlr.Dispose();
        }
        public void Renew()
        {
            pxlr = new PixelerVectoric(bmp);
        }
        public void Close()
        {
            pxlr.Dispose();
            bmp.Dispose();
            bmp = null;
        }

    }
    class FolderSource : Regular<InternalColor>
    {
        InternalColor[][] vss;
        float[][] As;
        float[][] Rs;
        float[][] Gs;
        float[][] Bs;

        public FolderSource(string[] paths)
        {
            foreach (var path in paths)
            {
                var bmp = new Bitmap(path);
                var pxlr = new Pixeler(bmp);
                if (As == null)
                {
                    As = General.NewMatrix<float>(bmp.Height, bmp.Width);
                    Rs = General.NewMatrix<float>(bmp.Height, bmp.Width);
                    Gs = General.NewMatrix<float>(bmp.Height, bmp.Width);
                    Bs = General.NewMatrix<float>(bmp.Height, bmp.Width);
                }
                int limq = As.Length;
                int limw = As[0].Length;
                if (bmp.Height < limq) limq = bmp.Height;
                if (bmp.Width < limw) limw = bmp.Width;
                for (int q = 0; q < limq; q++)
                {
                    var arow = As[q];
                    var rrow = Rs[q];
                    var grow = Gs[q];
                    var brow = Bs[q];
                    for (int w = 0; w < limw; w++)
                    {
                        var pix = pxlr.GetPixel(w, q);
                        arow[w] += pix.A;
                        rrow[w] += pix.R;
                        grow[w] += pix.G;
                        brow[w] += pix.B;
                    }
                }
                pxlr.Dispose();
                bmp.Dispose();
            }
            var k = 1.0f / (255 * paths.Length);
            for (int q = 0; q < As.Length; q++)
            {
                var arow = As[q];
                var rrow = Rs[q];
                var grow = Gs[q];
                var brow = Bs[q];
                for (int w = 0; w < arow.Length; w++)
                {
                    arow[w] *= k;
                    rrow[w] *= k;
                    grow[w] *= k;
                    brow[w] *= k;
                }
            }

            OutputType = typeof(InternalColor);
            Inputs = new IProcessor[0];
        }
        public void FolderSourceLoadOld(string[] paths)
        {
            foreach (var path in paths)
            {
                var bmp = new Bitmap(path);
                var pxlr = new Pixeler(bmp);
                if (vss == null)
                {
                    vss = General.NewMatrix<InternalColor>(bmp.Height, bmp.Width);
                }
                int limq = vss.Length;
                int limw = vss[0].Length;
                if (bmp.Height < limq) limq = bmp.Height;
                if (bmp.Width < limw) limw = bmp.Width;
                for (int q = 0; q < limq; q++)
                {
                    var vs = vss[q];
                    for (int w = 0; w < limw; w++)
                    {
                        var v = vs[w];
                        var pix = pxlr.GetPixel(w, q);
                        v.A += pix.A;
                        v.R += pix.R;
                        v.G += pix.G;
                        v.B += pix.B;
                        vs[w] = v;
                    }
                }
                pxlr.Dispose();
                bmp.Dispose();
            }
            var k = 1.0f / (255 * paths.Length);
            for (int q = 0; q < vss.Length; q++)
            {
                var vs = vss[q];
                for (int w = 0; w < vs.Length; w++)
                {
                    var v = vs[w];
                    v.A *= k;
                    v.R *= k;
                    v.G *= k;
                    v.B *= k;
                    vs[w] = v;
                }
            }

            OutputType = typeof(InternalColor);
            Inputs = new IProcessor[0];
        }

        public override InternalColor EvaluateC(Point p)
        {
            return new InternalColor(As[p.Y][p.X], Rs[p.Y][p.X], Gs[p.Y][p.X], Bs[p.Y][p.X]);
            //return vss[p.Y][p.X];
        }
        public override VectorColor EvaluateC(int x, int y, int th)
        {
            return new VectorColor(new Vector<float>(As[y], x), new Vector<float>(Rs[y], x), new Vector<float>(Gs[y], x), new Vector<float>(Bs[y], x));
        }
        public override bool CanEvaluate()
        {
            return true;
        }
        public override Size GetSize()
        {
            return new Size(As[0].Length, As.Length);
        }

        public void Dispose()
        {
            
        }
        public void Close()
        {
            
        }
    }
    [Serializable]
    class ImgResult : IProcessor
    {
        public ImgResult()
        {
            InputType = new Type[] { typeof(InternalColor) };
            Inputs = new IProcessor[1];
        }

        public override InternalColor EvaluateC(Point p)
        {
            return Inputs[0].EvaluateC(p);
        }
    }
    [Serializable]
    abstract class Regular<O> : IProcessor
    {
        public Regular()
        {
            InputType = new Type[0];
            OutputType = typeof(O);
            Inputs = new IProcessor[0];
        }

        public virtual IBox GenerateBox(Point start)
        {
            return new BoxRegular(start, this, 0);
        }
    }
    [Serializable]
    abstract class Regular1<I, O> : IProcessor
    {
        public Regular1()
        {
            InputType = new Type[] { typeof(I) };
            OutputType = typeof(O);
            Inputs = new IProcessor[1];
        }

        public virtual IBox GenerateBox(Point start)
        {
            return new BoxRegular(start, this, 1);
        }
    }
    [Serializable]
    abstract class Regular2<I1, I2, O> : IProcessor
    {
        public Regular2()
        {
            InputType = new Type[] { typeof(I1), typeof(I2) };
            OutputType = typeof(O);
            Inputs = new IProcessor[2];
        }

        public IBox GenerateBox(Point start)
        {
            return new BoxRegular(start, this, 2);
        }
    }
    [Serializable]
    abstract class Regular3<I1, I2, I3, O> : IProcessor
    {
        public Regular3()
        {
            InputType = new Type[] { typeof(I1), typeof(I2), typeof(I3) };
            OutputType = typeof(O);
            Inputs = new IProcessor[3];
        }

        public IBox GenerateBox(Point start)
        {
            return new BoxRegular(start, this, 3);
        }
    }
    [Serializable]
    abstract class Regular4<I1, I2, I3, I4, O> : IProcessor
    {
        public Regular4()
        {
            InputType = new Type[] { typeof(I1), typeof(I2), typeof(I3), typeof(I4) };
            OutputType = typeof(O);
            Inputs = new IProcessor[4];
        }

        public IBox GenerateBox(Point start)
        {
            return new BoxRegular(start, this, 4);
        }
    }
    [Serializable]
    abstract class Regular5<I1, I2, I3, I4, I5, O> : IProcessor
    {
        public Regular5()
        {
            InputType = new Type[] { typeof(I1), typeof(I2), typeof(I3), typeof(I4), typeof(I5) };
            OutputType = typeof(O);
            Inputs = new IProcessor[5];
        }

        public IBox GenerateBox(Point start)
        {
            return new BoxRegular(start, this, 5);
        }
    }
    [Serializable]
    class RawColorToA : Regular1<InternalColor, float>
    {
        public override float Evaluate(Point p)
        {
            return Inputs[0].EvaluateC(p).A;
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            return Inputs[0].EvaluateCv(x, y, th).As;
        }
    }
    [Serializable]
    class RawColorToR : Regular1<InternalColor, float>
    {
        public override float Evaluate(Point p)
        {
            return Inputs[0].EvaluateC(p).R;
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            return Inputs[0].EvaluateCv(x, y, th).Rs;
        }
    }
    [Serializable]
    class RawColorToG : Regular1<InternalColor, float>
    {
        public override float Evaluate(Point p)
        {
            return Inputs[0].EvaluateC(p).G;
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            return Inputs[0].EvaluateCv(x, y, th).Gs;
        }
    }
    [Serializable]
    class RawColorToB : Regular1<InternalColor, float>
    {
        public override float Evaluate(Point p)
        {
            return Inputs[0].EvaluateC(p).B;
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            return Inputs[0].EvaluateCv(x, y, th).Bs;
        }
    }
    [Serializable]
    class ARGBToRawColor : Regular4<float, float, float, float, InternalColor>
    {
        public override InternalColor EvaluateC(Point p)
        {
            return new InternalColor(Inputs[0].Evaluate(p), Inputs[1].Evaluate(p), Inputs[2].Evaluate(p), Inputs[3].Evaluate(p));
        }
        public override VectorColor EvaluateC(int x, int y, int th)
        {
            return new VectorColor(Inputs[0].Evaluatev(x, y, th), Inputs[1].Evaluatev(x, y, th), Inputs[2].Evaluatev(x, y, th), Inputs[3].Evaluatev(x, y, th));
        }
    }
    [Serializable]
    class RGBToRawColor : Regular3<float, float, float, InternalColor>
    {
        public override InternalColor EvaluateC(Point p)
        {
            return new InternalColor(Inputs[0].Evaluate(p), Inputs[1].Evaluate(p), Inputs[2].Evaluate(p));
        }
        public override VectorColor EvaluateC(int x, int y, int th)
        {
            return new VectorColor(VectorColor.VONE, Inputs[0].Evaluatev(x, y, th), Inputs[1].Evaluatev(x, y, th), Inputs[2].Evaluatev(x, y, th));
        }
    }
    [Serializable]
    class HSBToRawColor : Regular3<float, float, float, InternalColor>
    {
        static Vector<float> VMAXRAD = new Vector<float>((float)(Math.Sqrt(6) / 3));

        public override InternalColor EvaluateC(Point p)
        {
            return InternalColor.FromHSB(Inputs[0].Evaluate(p), Inputs[1].Evaluate(p), Inputs[2].Evaluate(p));
        }
        public override VectorColor EvaluateC(int x, int y, int th)
        {
            var H = Inputs[0].Evaluatev(x, y, th);
            var S = Inputs[1].Evaluatev(x, y, th);
            var B = Inputs[2].Evaluatev(x, y, th);

            var dy = HCBToRawColor.Sinus(H);
            var dx = MthVector.SignBinary(Vector.Abs(MthVector.FHALF - H) - MthVector.FQUART) * Vector.SquareRoot(MthVector.FONE - dy * dy);
            dx *= VMAXRAD;
            dy = dy * VMAXRAD * HCBToRawColor.VLYYZ;
            var vx = dx * HCBToRawColor.VLXX;
            var vy = dx * HCBToRawColor.VLXYZ + dy;
            var vz = dx * HCBToRawColor.VLXYZ - dy;

            var sx = MthVector.SignBinary(vx);
            var sy = MthVector.SignBinary(vy);
            var sz = MthVector.SignBinary(vz);
            var maxx = (sx * sx + sx) * MthVector.FHALF - sx * B;
            var maxy = (sy * sy + sy) * MthVector.FHALF - sy * B;
            var maxz = (sz * sz + sz) * MthVector.FHALF - sz * B;

            var kx = Vector.Abs(maxx / vx);
            var ky = Vector.Abs(maxy / vy);
            var kz = Vector.Abs(maxz / vz);
            var sel = Vector.LessThan(kx, ky);
            var k = Vector.ConditionalSelect(sel, kx, ky);
            var km = Vector.ConditionalSelect(sel, maxx, maxy);
            var kd = Vector.ConditionalSelect(sel, vx, vy);
            sel = Vector.LessThan(k, kz);
            k = Vector.ConditionalSelect(sel, k, kz);
            km = Vector.ConditionalSelect(sel, km, maxz);
            kd = Vector.ConditionalSelect(sel, kd, vz);
            kd = Vector.Abs(kd);

            return new VectorColor(MthVector.FONE, B + S * vx / kd * km, B + S * vy / kd * km, B + S * vz / kd * km);
        }
    }
    [Serializable]
    class HCBToRawColor : Regular3<float, float, float, InternalColor>
    {
        const float From01ToRad = (float)(Math.PI * 2);
        const float K1 = 1.0f / 6;
        const float K2 = 1.0f / 120;
        const float K3 = 1.0f / 5040;
        const float LXX = (float)(2.0 / 3);
        const float LXYZ = (float)(-1.0 / 3);
        const float LYYZ = (float)(0.5773502691896257);
        static readonly Vector<float> VK1 = new Vector<float>(K1);
        static readonly Vector<float> VK2 = new Vector<float>(K2);
        static readonly Vector<float> VK3 = new Vector<float>(K3);
        public static readonly Vector<float> VTHREEQUART = new Vector<float>(0.75f);
        public static readonly Vector<float> VNEGHALF = new Vector<float>(-0.5f);
        public static readonly Vector<float> VLXX = new Vector<float>(LXX);
        public static readonly Vector<float> VLXYZ = new Vector<float>(LXYZ);
        public static readonly Vector<float> VLYYZ = new Vector<float>(LYYZ);
        public static readonly Vector<int> ISIX = new Vector<int>(6);

        public override InternalColor EvaluateC(Point p)
        {
            return InternalColor.FromHCB(Inputs[0].Evaluate(p), Inputs[1].Evaluate(p), Inputs[2].Evaluate(p));
        }

        public override VectorColor EvaluateC(int x, int y, int th)
        {
            var H = Inputs[0].Evaluatev(x, y, th);
            var C = Inputs[1].Evaluatev(x, y, th);
            var B = Inputs[2].Evaluatev(x, y, th);

            var dy = Sinus(H);
            var dx = MthVector.SignBinary(Vector.Abs(MthVector.FHALF - H) - MthVector.FQUART) * Vector.SquareRoot(MthVector.FONE - dy * dy);
            dx *= C;
            dy = dy * C * VLYYZ;
            var vx = dx * VLXX;
            var vy = dx * VLXYZ + dy;
            var vz = dx * VLXYZ - dy;

            var sx = MthVector.SignBinary(vx);
            var sy = MthVector.SignBinary(vy);
            var sz = MthVector.SignBinary(vz);
            var maxx = (sx * sx + sx) * MthVector.FHALF - sx * B;
            var maxy = (sy * sy + sy) * MthVector.FHALF - sy * B;
            var maxz = (sz * sz + sz) * MthVector.FHALF - sz * B;

            var kx = Vector.Abs(maxx / vx);
            var ky = Vector.Abs(maxy / vy);
            var kz = Vector.Abs(maxz / vz);
            var sel = Vector.LessThan(kx, ky);
            var k = Vector.ConditionalSelect(sel, kx, ky);
            var km = Vector.ConditionalSelect(sel, maxx, maxy);
            var kd = Vector.ConditionalSelect(sel, vx, vy);
            sel = Vector.LessThan(k, kz);
            k = Vector.ConditionalSelect(sel, k, kz);
            km = Vector.ConditionalSelect(sel, km, maxz);
            kd = Vector.ConditionalSelect(sel, kd, vz);
            sel = Vector.LessThan(k, MthVector.FONE);
            km = Vector.ConditionalSelect(sel, km, MthVector.FONE);
            kd = Vector.ConditionalSelect(sel, kd, MthVector.FONE);
            kd = Vector.Abs(kd);

            return new VectorColor(MthVector.FONE, B + vx / kd * km, B + vy / kd * km, B + vz / kd * km);
        }

        public static Tripl<float> FromHCB(float H, float C, float B)
        {
            //var dx = (float)Math.Cos(From01ToRad * H);
            //var dy = Math.Sign(0.5 - H) * (float)Math.Sqrt(1 - dx * dx);
            var dy = Sinus(H);
            var dx = Math.Sign(Math.Abs(0.5f - H) - 0.25f) * (float)Math.Sqrt(1 - dy * dy);
            dx *= C;
            dy = dy * C * LYYZ;
            var vx = dx * LXX;
            var vy = dx * LXYZ + dy;
            var vz = dx * LXYZ - dy;

            var sx = (float)Math.Sign(vx);
            var sy = (float)Math.Sign(vy);
            var sz = (float)Math.Sign(vz);
            var maxx = (sx * sx + sx) * 0.5f - sx * B;
            var maxy = (sy * sy + sy) * 0.5f - sy * B;
            var maxz = (sz * sz + sz) * 0.5f - sz * B;

            var kx = Math.Abs(maxx / vx);
            var ky = Math.Abs(maxy / vy);
            var kz = Math.Abs(maxz / vz);
            var km = 1.0f;
            var kd = 1.0f;
            if (kx < ky)
            {
                if (kx < kz)
                {
                    if (kx < 1)
                    {
                        km = maxx;
                        kd = vx;
                    }
                }
                else
                {
                    if (kz < 1)
                    {
                        km = maxz;
                        kd = vz;
                    }
                }
            }
            else
            {
                if (ky < kz)
                {
                    if (ky < 1)
                    {
                        km = maxy;
                        kd = vy;
                    }
                }
                else
                {
                    if (kz < 1)
                    {
                        km = maxz;
                        kd = vz;
                    }
                }
            }

            kd = Math.Abs(kd);
            return new Tripl<float>(B + vx / kd * km, B + vy / kd * km, B + vz / kd * km);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="x">Between 0 and 1</param>
        /// <returns></returns>
        public static float Sinus0(float x)
        {
            var k = ((int)((x + 0.25f) * 2)) * 0.5f;
            var si = (float)Math.Sign(Math.Abs(0.5f - x) - 0.25f);
            var ks = Math.Sign(0.75f - x);
            x = x * si + ks * k;

            //var pi = (float)Math.PI;
            //var pihalf = (float)(Math.PI / 2);

            x *= (float)(Math.PI * 2);

            //var s = Math.Sign(x);
            //var a = Math.Sign(pihalf - Math.Abs(x));
            //var bb = (a - 1) * -0.5f;
            //x = pi * s * bb + a * x;
            
            var x3 = x * x * x;
            var x5 = x3 * x * x;
            var x7 = x3 * x3 * x;
            var k1 = 1.0f / 6;
            var k2 = 1.0f / 120;
            var k3 = 1.0f / 5040;

            var b = x3 * k1;
            var c = x5 * k2;
            var d = x7 * k3;

            var ret = x - b;// + c - d;
            System.Diagnostics.Debug.Assert(ret >= -1 && ret <= 1);
            return ret;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x">Between 0 and 1</param>
        /// <returns></returns>
        public static float Sinus(float x)
        {
            var k = ((int)((x + 0.25f) * 2)) * 0.5f;
            var si = (float)Math.Sign(Math.Abs(0.5f - x) - 0.25f);
            var ks = Math.Sign(0.75f - x);
            x = x * si + ks * k;
            
            x *= From01ToRad;
            var x3 = x * x * x;
            return x - x3 * K1 + x3 * x * x * K2 - x3 * x3 * x * K3;
        }
        public static Vector<float> Sinus(Vector<float> x)
        {
            var i4 = Vector.ConvertToInt32(x * MthVector.FFOUR);
            var i3 = i4 - MthVector.IONE;
            var i5 = i4 + MthVector.IONE;
            var i01 = Vector.BitwiseAnd(i3, MthVector.ITWO);
            var sign = Vector.ConvertToSingle(i01 - MthVector.IONE);
            var ks = Vector.ConvertToSingle(Vector.BitwiseAnd(i5, ISIX)) * MthVector.FQUART;
            var ki = Vector.ConvertToSingle(Vector.BitwiseAnd(i5, MthVector.IFOUR) - MthVector.ITWO) * VNEGHALF;
            x = x * sign + ks * ki;

            //var s = new BinaryFloat(x[0]).ToString();
            //var k = new Vector<float>();
            //k = Vector.ConditionalSelect(Vector.GreaterThanOrEqual(x, MthVector.VQUART), MthVector.VHALF, MthVector.VZERO);
            //k = Vector.ConditionalSelect(Vector.GreaterThan(x, VTHREEQUART), MthVector.VNEGONE, k);
            //var a = MthVector.VHALF - x;
            //s = new BinaryFloat(a[0]).ToString();
            //var b = Vector.Abs(MthVector.VHALF - x) - MthVector.VQUART;
            //s = new BinaryFloat(b[0]).ToString();
            //var si = Vector.ConditionalSelect(Vector.GreaterThan(Vector.Abs(MthVector.VHALF - x) - MthVector.VQUART, MthVector.VZERO), MthVector.VONE, MthVector.VNEGONE);
            //si = MthVector.Sign(Vector.Abs(MthVector.VHALF - x) - MthVector.VQUART);
            //x = x * si + k;

            x *= MthVector.FPI2;
            var x3 = x * x * x;
            return x - x3 * VK1 + x3 * x * x * VK2 - x3 * x3 * x * VK3;
        }
    }
    [Serializable]
    class RGBToDouble : Regular1<InternalColor, float>
    {
        const int MASK = 256 * 256 * 256 - 1;
        const float RGBMAX = 256 * 256 * 256 - 1;
        //static readonly Vector<int> VMASK;
        //static readonly Vector<float> V_RGBMAX;

        //static RGBToDouble()
        //{
        //    VMASK = new Vector<int>(MASK);
        //    var v = (float)(1 / RGBMAX);
        //    V_RGBMAX = new Vector<float>(v);
        //}

        public override float Evaluate(Point p)
        {
            var col = Inputs[0].EvaluateC(p);
            var rc = (RawColor)col;
            return (rc.ARGB & MASK) / RGBMAX;
        }
        
    }
    [Serializable]
    class RawColorHolder : Regular1<InternalColor, InternalColor>
    {
        public override InternalColor EvaluateC(Point p)
        {
            return Inputs[0].EvaluateC(p);
        }
    }
    [Serializable]
    class RawColorToHue : Regular1<InternalColor, float>
    {
        const float RADTO01 = (float)(1 / (Math.PI * 2));
        static readonly Vector<float> VRADTO01;
        static readonly Vector<float> VA = new Vector<float>(-0.0187293f);
        static readonly Vector<float> VB = new Vector<float>(0.0742610f);
        static readonly Vector<float> VC = new Vector<float>(-0.2121144f);
        static readonly Vector<float> VD = new Vector<float>(1.5707288f);
        static readonly Vector<float> VMIN2PI = new Vector<float>((float)(-0.5 * Math.PI));
        static RawColorToHue()
        {
            VRADTO01 = new Vector<float>((float)RADTO01);
        }
        public override float Evaluate(Point p)
        {
            var col = Inputs[0].EvaluateC(p);

            var a = col.B - col.G;
            var b = col.R - col.B;
            var c = col.G - col.R;

            var s2 = (float)Math.Sqrt((a * a + b * b + c * c) * 2);
            if (s2 == 0) return 0;
            var ang = (float)Math.Acos((b - c) / s2) * RADTO01;
            if (a > 0) ang = 1 - ang;

            return ang;

            //return col.HSB().Item1;
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            var cols = Inputs[0].EvaluateCv(x, y, th);
            var a = cols.Bs - cols.Gs;
            var b = cols.Rs - cols.Bs;
            var c = cols.Gs - cols.Rs;

            var s2 = Vector.SquareRoot((a * a + b * b + c * c) * VectorColor.VTWO);
            var ins = (b - c) / s2;
            var vs = new float[VectorColor.Count];
            for (int q = 0; q < vs.Length; q++)
            {
                vs[q] = (float)Math.Acos(ins[q]);
            }
            var ang = new Vector<float>(vs) * VRADTO01;
            //var ang = ACos(ins) * VRADTO01;
            ang = Vector.ConditionalSelect(Vector.Equals(s2, VectorColor.VZERO), VectorColor.VZERO, ang);
            var inv = VectorColor.VONE - ang;

            return Vector.ConditionalSelect(Vector.GreaterThan(a, VectorColor.VZERO), inv, ang);
        }

        public static float ACos(float x)
        {
            var s = x;
            x = Math.Abs(x);
            //var r = (((-0.0187293f * x + 0.0742610f) * x - 0.2121144f) * x + 1.5707288f) * (float)Math.Sqrt(1 - x);
            var xx = x * x;
            var r = (-0.0187293f * xx * x + 0.0742610f * xx - 0.2121144f * x + 1.5707288f) * (float)Math.Sqrt(1 - x);
            if (s < 0) return (float)Math.PI - r;
            else return r;
        }

        public static Vector<float> ACos(Vector<float> x)
        {
            var s = MthVector.SignBinary(x);
            x = Vector.Abs(x);
            var xx = x * x;
            var r = (VA * xx * x + VB * xx + VC * x + VD) * Vector.SquareRoot(MthVector.FONE - x);
            return (s - MthVector.FONE) * VMIN2PI + s * r;
        }
        public static float ACos1(float x)
        {
            float pihalf = (float)(Math.PI * 0.5);
            float sign = -1;
            if (x < -0.5f || x > 0.5f)
            {
                pihalf = 0;
                sign = 1;
            }
            float K1 = 1f / 6;
            float K2 = 3f / 40;
            float K3 = 15f / 336;
            var x3 = x * x * x;
            return pihalf + sign * (x + x3 * K1 + x3 * x * x * K2 + x3 * x3 * x * K3);
        }
        public static float ASin(float x)
        {
            float K1 = 1f / 6;
            float K2 = 3f / 40;
            float K3 = 15f / 336;
            var x3 = x * x * x;
            return x + x3 * K1 + x3 * x * x * K2 + x3 * x3 * x * K3;
        }
    }
    [Serializable]
    class RawColorToSaturation : Regular1<InternalColor, float>
    {
        public override float Evaluate(Point p)
        {
            var col = Inputs[0].EvaluateC(p);
            return col.Saturation();
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            var col = Inputs[0].EvaluateCv(x, y, th);

            var Bri = (col.Rs + col.Gs + col.Bs) * MthVector.FTHIRD;

            var vx = col.Rs - Bri;
            var vy = col.Gs - Bri;
            var vz = col.Bs - Bri;

            var sx = MthVector.Sign(vx);
            var sy = MthVector.Sign(vy);
            var sz = MthVector.Sign(vz);
            var maxx = (sx + MthVector.FONE) * MthVector.FHALF - sx * Bri;
            var maxy = (sy + MthVector.FONE) * MthVector.FHALF - sy * Bri;
            var maxz = (sz + MthVector.FONE) * MthVector.FHALF - sz * Bri;

            var kx = Vector.Abs(vx) / maxx;
            var ky = Vector.Abs(vy) / maxy;
            var kz = Vector.Abs(vz) / maxz;

            var k = Vector.Max(kx, Vector.Max(ky, kz));
            return k;
        }
    }
    [Serializable]
    class RawColorToColorful : Regular1<InternalColor, float>
    {
        //static readonly double a;
        //static readonly double k;
        const float _k = 0.70710685f;
        //static readonly Vector<float> va;
        //static readonly Vector<float> vk;
        static readonly Vector<float> v_k;

        static RawColorToColorful()
        {
            //a = Math.Sqrt(3);
            //k = 2 / (a * Mth3D.DistPointToLine(new Point3D(1, 0, 0), new Point3D(), new Point3D(1, 1, 1)));
            //_k = 0.70710685f;
            //va = new Vector<float>((float)a);
            //vk = new Vector<float>((float)k);
            v_k = new Vector<float>(_k);
        }
        
        public override float Evaluate(Point p)
        {
            var col = Inputs[0].EvaluateC(p);

            var cpx = col.B - col.G;
            var cpy = col.R - col.B;
            var cpz = col.G - col.R;

            return (float)Math.Sqrt(cpx * cpx + cpy * cpy + cpz * cpz) * _k;

            //var b = Mth3D.Dist(col.R, col.G, col.B);
            //var c = Mth3D.Dist(col.R - 1, col.G - 1, col.B - 1);

            //var ret = col.HCB().Item2;
            //var ret2 = Mth.TriangleArea(a, b, c) * k;

            //return Mth.TriangleArea(a, b, c) * k;
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            var col = Inputs[0].EvaluateCv(x, y, th);

            var cpx = col.Bs - col.Gs;
            var cpy = col.Rs - col.Bs;
            var cpz = col.Gs - col.Rs;

            return Vector.SquareRoot(cpx * cpx + cpy * cpy + cpz * cpz) * v_k;

            //var b = MthVector.Dist(cols.Rs, cols.Gs, cols.Bs);
            //var c = MthVector.Dist(cols.Rs - MthVector.VONE, cols.Gs - MthVector.VONE, cols.Bs - MthVector.VONE);

            //var s = (va + b + c) * MthVector.VHALF;
            //var aeras = Vector.SquareRoot(s * (s - va) * (s - b) * (s - c));

            //return aeras * vk;
        }
    }
    [Serializable]
    class RawColorToBrightness : Regular1<InternalColor, float>
    {
        const float THIRD = 1.0f / 3;
        public override float Evaluate(Point p)
        {
            var col = Inputs[0].EvaluateC(p);
            return (col.R + col.G + col.B) * THIRD;
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            var col = Inputs[0].EvaluateCv(x, y, th);
            return (col.Rs + col.Gs + col.Bs) * VectorColor.VTHIRD;
        }
    }
    [Serializable]
    class DoubleToGrayScale : Regular1<float, InternalColor>
    {
        public override InternalColor EvaluateC(Point p)
        {
            var v = Inputs[0].Evaluate(p);
            return new InternalColor(v, v, v);
        }
        public override VectorColor EvaluateC(int x, int y, int th)
        {
            var v = Inputs[0].Evaluatev(x, y, th);
            return new VectorColor(VectorColor.VONE, v, v, v);
        }
    }
    [Serializable]
    abstract class OneDoubleInput : Regular1<float, float>
    {

    }
    [Serializable]
    class Invert : OneDoubleInput
    {
        public override float Evaluate(Point p)
        {
            return 1.0f - Inputs[0].Evaluate(p);
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            return VectorColor.VONE - Inputs[0].Evaluatev(x, y, th);
        }
    }
    [Serializable]
    class Trim : OneDoubleInput
    {
        public override float Evaluate(Point p)
        {
            var v = Inputs[0].Evaluate(p);
            if (v < 0) return 0.0f;
            if (v > 1) return 1.0f;
            return v;
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            var vs = Inputs[0].Evaluatev(x, y, th);

            vs = Vector.Max(vs, MthVector.FZERO);
            return Vector.Min(vs, MthVector.FONE);

            //var lt = Vector.LessThan(vs, VectorColor.VZERO);
            //var gt = Vector.GreaterThan(vs, VectorColor.VONE);
            //var ret = Vector.ConditionalSelect(lt, VectorColor.VZERO, vs);
            //ret = Vector.ConditionalSelect(gt, VectorColor.VONE, vs);
            //return ret;
        }
    }
    [Serializable]
    class SqRoot : OneDoubleInput
    {
        public override float Evaluate(Point p)
        {
            return (float)Math.Sqrt(Inputs[0].Evaluate(p));
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            return Vector.SquareRoot(Inputs[0].Evaluatev(x, y, th));
        }
    }
    [Serializable]
    class Sin : OneDoubleInput
    {
        public override float Evaluate(Point p)
        {
            return (float)Math.Sin(Mth.PI2 * Inputs[0].Evaluate(p)) * 0.5f + 0.5f;
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            var inp = Inputs[0].Evaluatev(x, y, th) * VectorColor.VPI2;
            var vs = new float[VectorColor.Count];
            for (int q = 0; q < vs.Length; q++)
            {
                vs[q] = (float)Math.Sin(inp[q]);
            }
            return new Vector<float>(vs) * VectorColor.VHALF + VectorColor.VHALF;
        }
    }
    [Serializable]
    class ASin : OneDoubleInput
    {
        public override float Evaluate(Point p)
        {
            return (float)(Math.Asin(2 * Inputs[0].Evaluate(p) - 1) / Math.PI);
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            var inp = Inputs[0].Evaluatev(x, y, th) * VectorColor.VTWO - VectorColor.VONE;
            var vs = new float[VectorColor.Count];
            for (int q = 0; q < vs.Length; q++)
            {
                vs[q] = (float)Math.Asin(inp[q]);
            }
            return new Vector<float>(vs) / VectorColor.VPI;
        }
    }
    [Serializable]
    class SlopeTan : OneDoubleInput
    {
        public override float Evaluate(Point p)
        {
            return (float)Math.Tan(Mth.PIHalf * Inputs[0].Evaluate(p));
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            var inp = Inputs[0].Evaluatev(x, y, th) * VectorColor.VPIHALF;
            var vs = new float[VectorColor.Count];
            for (int q = 0; q < vs.Length; q++)
            {
                vs[q] = (float)Math.Tan(inp[q]);
            }
            return new Vector<float>(vs);
        }
    }
    [Serializable]
    class RoundTo01 : OneDoubleInput
    {
        public override float Evaluate(Point p)
        {
            var v = Inputs[0].Evaluate(p);
            if (v < 0.5f) return 0.0f;
            else return 1.0f;
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            return Vector.ConditionalSelect(Vector.LessThan(Inputs[0].Evaluatev(x, y, th), VectorColor.VHALF), VectorColor.VZERO, VectorColor.VONE);
        }
    }
    [Serializable]
    class SafeAdd : Regular2<float, float, float>
    {
        public override float Evaluate(Point p)
        {
            var ret = Inputs[0].Evaluate(p) + Inputs[1].Evaluate(p);
            if (ret > 1) ret = 1;
            return ret;
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            var sum = Vector.Add(Inputs[0].Evaluatev(x, y, th), Inputs[1].Evaluatev(x, y, th));
            return Vector.Min(sum, MthVector.FONE);
            //return Vector.ConditionalSelect(Vector.GreaterThan(sum, VectorColor.VONE), VectorColor.VONE, sum);
        }
    }
    [Serializable]
    class SafeSubtract : Regular2<float, float, float>
    {
        public override float Evaluate(Point p)
        {
            var ret = Inputs[0].Evaluate(p) - Inputs[1].Evaluate(p);
            if (ret < 0) ret = 0;
            return ret;
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            var sum = Vector.Subtract(Inputs[0].Evaluatev(x, y, th), Inputs[1].Evaluatev(x, y, th));
            return Vector.Max(sum, MthVector.FZERO);
            //return Vector.ConditionalSelect(Vector.LessThan(sum, VectorColor.VZERO), VectorColor.VZERO, sum);
        }
    }
    [Serializable]
    class CircularAdd : Regular2<float, float, float>
    {
        public override float Evaluate(Point p)
        {
            var ret = Inputs[0].Evaluate(p) + Inputs[1].Evaluate(p);
            if (ret > 1) ret -= 1;
            return ret;
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            var sum = Vector.Add(Inputs[0].Evaluatev(x, y, th), Inputs[1].Evaluatev(x, y, th));
            var summ1 = Vector.Subtract(sum, VectorColor.VONE);
            return Vector.ConditionalSelect(Vector.GreaterThan(sum, VectorColor.VONE), summ1, sum);
        }
    }
    [Serializable]
    class Add : Regular2<float, float, float>
    {
        public override float Evaluate(Point p)
        {
            return Inputs[0].Evaluate(p) + Inputs[1].Evaluate(p);
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            return Vector.Add(Inputs[0].Evaluatev(x, y, th), Inputs[1].Evaluatev(x, y, th));
        }
    }
    [Serializable]
    class Subtract : Regular2<float, float, float>
    {
        public override float Evaluate(Point p)
        {
            return Inputs[0].Evaluate(p) - Inputs[1].Evaluate(p);
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            return Vector.Subtract(Inputs[0].Evaluatev(x, y, th), Inputs[1].Evaluatev(x, y, th));
        }
    }
    [Serializable]
    class Multiply : Regular2<float, float, float>
    {
        public override float Evaluate(Point p)
        {
            return Inputs[0].Evaluate(p) * Inputs[1].Evaluate(p);
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            return Vector.Multiply(Inputs[0].Evaluatev(x, y, th), Inputs[1].Evaluatev(x, y, th));
        }
    }
    [Serializable]
    class Divide : Regular2<float, float, float>
    {
        public override float Evaluate(Point p)
        {
            return Inputs[0].Evaluate(p) / Inputs[1].Evaluate(p);
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            return Vector.Divide(Inputs[0].Evaluatev(x, y, th), Inputs[1].Evaluatev(x, y, th));
        }
    }
    //class SphericDistance : Regular4<double, double, double, double, double>
    //{
    //    public override object Evaluate(Point p)
    //    {
    //        var pa=new PointD((double)Inputs[0].Evaluate(p)*Mth.PI2, (double)Inputs[0].Evaluate(p))
    //        Mth.SphericDistance()
    //        return ((double)Inputs[0].Evaluate(p) + (double)Inputs[1].Evaluate(p)) * 0.5;
    //    }
    //}
    [Serializable]
    class Min : Regular2<float, float, float>
    {
        public override float Evaluate(Point p)
        {
            return Math.Min(Inputs[0].Evaluate(p), Inputs[1].Evaluate(p));
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            return Vector.Min(Inputs[0].Evaluatev(x, y, th), Inputs[1].Evaluatev(x, y, th));
        }
    }
    [Serializable]
    class Max : Regular2<float, float, float>
    {
        public override float Evaluate(Point p)
        {
            return Math.Max(Inputs[0].Evaluate(p), Inputs[1].Evaluate(p));
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            return Vector.Max(Inputs[0].Evaluatev(x, y, th), Inputs[1].Evaluatev(x, y, th));
        }
    }
    [Serializable]
    class Mean : Regular2<float, float, float>
    {
        public override float Evaluate(Point p)
        {
            return (Inputs[0].Evaluate(p) + Inputs[1].Evaluate(p)) * 0.5f;
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            return Vector.Multiply(Vector.Add(Inputs[0].Evaluatev(x, y, th), Inputs[1].Evaluatev(x, y, th)), VectorColor.VHALF);
        }
    }
    [Serializable]
    class Mean3 : Regular3<float, float, float, float>
    {
        const float THIRD = 1.0f / 3;
        public override float Evaluate(Point p)
        {
            return (Inputs[0].Evaluate(p) + Inputs[1].Evaluate(p) + Inputs[2].Evaluate(p)) * THIRD;
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            return (Inputs[0].Evaluatev(x, y, th) + Inputs[1].Evaluatev(x, y, th) + Inputs[2].Evaluatev(x, y, th)) * VectorColor.VTHIRD;
        }
    }
    [Serializable]
    class Rand : Regular<float>
    {
        Random rnd = new Random();
        
        public override float Evaluate(Point p)
        {
            return (float)rnd.NextDouble();
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            var vs = new float[VectorColor.Count];
            for (int q = 0; q < vs.Length; q++)
            {
                vs[q] = (float)rnd.NextDouble();
            }
            return new Vector<float>(vs);
        }
    }
    [Serializable]
    class Value : Regular<float>
    {
        float v;
        Vector<float> vs;

        public float V
        {
            get
            {
                return v;
            }
            set
            {
                v = value;
                vs = new Vector<float>(value);
            }
        }

        public override float Evaluate(Point p)
        {
            return v;
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            return vs;
        }
    }
    [Serializable]
    class SingleColor : Regular<InternalColor>
    {
        InternalColor v;
        VectorColor vc;
        public InternalColor V
        {
            get
            {
                return v;
            }
            set
            {
                v = value;
                vc = new VectorColor(new Vector<float>((float)value.A), new Vector<float>((float)value.R), new Vector<float>((float)value.G), new Vector<float>((float)value.B));
            }
        }

        public override InternalColor EvaluateC(Point p)
        {
            return v;
        }
        public override VectorColor EvaluateC(int x, int y, int th)
        {
            return vc;
        }
    }
    [Serializable]
    class Opaque : Regular1<InternalColor, InternalColor>
    {
        public override InternalColor EvaluateC(Point p)
        {
            var col = Inputs[0].EvaluateC(p);
            return new InternalColor(1, col.R, col.G, col.B);
        }
        public override VectorColor EvaluateC(int x, int y, int th)
        {
            var col = Inputs[0].EvaluateCv(x, y, th);
            col.As = VectorColor.VONE;
            return col;
        }
    }
    [Serializable]
    class Merge : Regular3<InternalColor, float, InternalColor, InternalColor>
    {
        public override InternalColor EvaluateC(Point p)
        {
            var col1 = Inputs[0].EvaluateC(p);
            var col2 = Inputs[2].EvaluateC(p);
            var fac = Inputs[1].Evaluate(p);
            var inv = 1 - fac;
            return new InternalColor(col1.A * fac + col2.A * inv, col1.R * fac + col2.R * inv, col1.G * fac + col2.G * inv, col1.B * fac + col2.B * inv);
        }
        public override VectorColor EvaluateC(int x, int y, int th)
        {
            var col1 = Inputs[0].EvaluateCv(x, y, th);
            var col2 = Inputs[2].EvaluateCv(x, y, th);
            var fac = Inputs[1].Evaluatev(x, y, th);
            var inv = VectorColor.VONE - fac;
            return new VectorColor(col1.As * fac + col2.As * inv, col1.Rs * fac + col2.Rs * inv, col1.Gs * fac + col2.Gs * inv, col1.Bs * fac + col2.Bs * inv);
        }
    }
    [Serializable]
    class Paint : Regular2<InternalColor, InternalColor, InternalColor>
    {
        public override InternalColor EvaluateC(Point p)
        {
            var col1 = Inputs[0].EvaluateC(p);
            var col2 = Inputs[1].EvaluateC(p);
            var inv = col2.A;
            var fac = 1 - inv;
            return new InternalColor(1 - (1 - col1.A) * col2.A, col1.R * fac + col2.R * inv, col1.G * fac + col2.G * inv, col1.B * fac + col2.B * inv);
        }
        public override VectorColor EvaluateC(int x, int y, int th)
        {
            var col1 = Inputs[0].EvaluateCv(x, y, th);
            var col2 = Inputs[1].EvaluateCv(x, y, th);
            var inv = col2.As;
            var fac = VectorColor.VONE - inv;
            var na = VectorColor.VONE - (VectorColor.VONE - col1.As) * col2.As;
            return new VectorColor(na, col1.Rs * fac + col2.Rs * inv, col1.Gs * fac + col2.Gs * inv, col1.Bs * fac + col2.Bs * inv);
        }
    }
    [Serializable]
    class Adjust : OneDoubleInput
    {
        static readonly float[] STARTVS = new float[] { 0, 1 };
        public float[] vs;
        Vector<float>[] lims;
        Vector<float>[] vvs;
        Vector<float> vn;

        public Adjust(int N)
        {
            vs = STARTVS;
            ResetN(N);
        }
        public void ResetN(int N)
        {
            lims = new Vector<float>[N - 2];
            var step = 1.0f / (N - 1);
            var x = step;
            for (int q = 0; q < lims.Length; q++)
            {
                lims[q] = new Vector<float>(x);
                x += step;
            }
            vn = new Vector<float>(N - 1);
            var nvs = new float[N];
            vvs = new Vector<float>[N];
            for (int q = 0; q < nvs.Length; q++)
            {
                var ev = Evaluate((float)q / (nvs.Length - 1));
                nvs[q] = ev;
                vvs[q] = new Vector<float>(ev);
            }
            vs = nvs;
        }

        public void Set(float v, int i)
        {
            vs[i] = v;
            vvs[i] = new Vector<float>((float)v);
        }
        public override float Evaluate(Point p)
        {
            var d = Inputs[0].Evaluate(p);
            return Evaluate(d);
        }
        float Evaluate(float d)
        {
            if (d == 1) return vs[vs.Length - 1];
            int i = (int)(d * (vs.Length - 1));
            var low = vs[i];
            return low + (d - (float)i / (vs.Length - 1)) * (vs[i + 1] - low) * (vs.Length - 1);
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            var inp = Inputs[0].Evaluatev(x, y, th);
            var lo = vvs[0];
            var hi = vvs[1];
            for (int q = 0; q < lims.Length; q++)
            {
                var sel = Vector.GreaterThan(inp, lims[q]);
                lo = Vector.ConditionalSelect(sel, vvs[q + 1], lo);
                hi = Vector.ConditionalSelect(sel, vvs[q + 2], hi);
            }
            inp = inp * vn;
            var i = Vector.ConvertToInt32(inp);
            inp = inp - Vector.ConvertToSingle(i);

            return inp * hi + (MthVector.FONE - inp) * lo;
        }
    }
    [Serializable]
    class Intensifier : Regular2<float, float, float>
    {
        public override float Evaluate(Point p)
        {
            var a = Inputs[0].Evaluate(p);
            var i = Inputs[1].Evaluate(p);
            if (i < 0.5f)
            {
                return a * i * 2;
            }
            else
            {
                a = 1 - a;
                i = 1 - i;
                return 1 - a * i * 2;
                //return a + (1 - a) * (i - 0.5) * 2;
            }
        }
        public override Vector<float> Evaluate(int x, int y, int th)
        {


            return base.Evaluate(x, y, th);
        }
    }
    [Serializable]
    class Resizer : Regular2<InternalColor, float, InternalColor>
    {
        float[][][] arrss;

        public Resizer()
        {
            arrss = General.NewMatrix<float>(BoxResult.THREADN, 4, VectorColor.Count);
        }

        public override InternalColor EvaluateC(Point p)
        {
            var k = Inputs[1].Evaluate(new Point());
            p.X = (int)(p.X / k);
            p.Y = (int)(p.Y / k);
            return Inputs[0].EvaluateC(p);
        }
        public override VectorColor EvaluateC(int x, int y, int th)
        {
            var k = Inputs[1].Evaluate(new Point());
            var arr = arrss[th];
            var aa = arr[0];
            var rr = arr[1];
            var gg = arr[2];
            var bb = arr[3];
            var yy = (int)(y / k);
            for (int q = 0; q < aa.Length; q++)
            {
                var inp = Inputs[0].EvaluateC(new Point((int)((x + q) / k), yy));
                aa[q] = inp.A;
                rr[q] = inp.R;
                gg[q] = inp.G;
                bb[q] = inp.B;
            }
            return new VectorColor(new Vector<float>(aa), new Vector<float>(rr), new Vector<float>(gg), new Vector<float>(bb));
        }
        public override Size GetSize()
        {
            return (Size)resize((Point)base.GetSize());
        }
        Point resize(Point p)
        {
            var k = Inputs[1].Evaluate(new Point());
            p.X = (int)(p.X * k);
            p.Y = (int)(p.Y * k);
            return p;
        }
        public override bool CanEvaluate()
        {
            var item = Inputs[1];
            if (item != null && item.Evaluate(new Point()) == 0) return false;
            return base.CanEvaluate();
        }
    }
    [Serializable]
    class ColorEdge : Regular1<InternalColor, InternalColor>
    {
        public override InternalColor EvaluateC(Point p)
        {
            var c = Inputs[0].EvaluateC(p);
            var relx = c.R - 0.5f;
            var rely = c.G - 0.5f;
            var relz = c.B - 0.5f;
            var arelx = Math.Abs(relx);
            var arely = Math.Abs(rely);
            var arelz = Math.Abs(relz);
            var max = Math.Max(arelx, arely);
            max = Math.Max(arelz, max);
            var k = 0.5f / max;
            relx *= k;
            rely *= k;
            relz *= k;
            c.R = 0.5f + relx;
            c.G = 0.5f + rely;
            c.B = 0.5f + relz;
            return c;
        }
    }
    [Serializable]
    class ScriptOutVal : Regular5<float, float, float, InternalColor, InternalColor, float>
    {
        static readonly string NL = Environment.NewLine;
        static string[] sep = new string[] { Environment.NewLine };
        static string[] varNames = new string[] { "i0", "i1", "i2", "i3", "i4"};
        static string[][] colNames = new string[][] { null, null, null, new string[] { "i3a", "i3r", "i3g", "i3b" }, new string[] { "i4a", "i4r", "i4g", "i4b" } };
        static InternalColor colMid = new InternalColor(0.5f, 0.5f, 0.5f, 0.5f);
        static string[] keywords = new string[] { "exceptionThrown", "vectorN", "length", "os", "is0", "is1", "is2", "is3a", "is3r", "is3g", "is3b", "is4a", "is4r", "is4g", "is4b", "x", "y" };
        public string CoreScript = "";
        [NonSerialized]
        ScriptEngine eng;
        [NonSerialized]
        ScriptSource script;
        [NonSerialized]
        ScriptScope scope;
        [NonSerialized]
        ScriptSource vscript;
        [NonSerialized]
        ScriptScope[] vscope_;
        [NonSerialized]
        int[] lasty;
        [NonSerialized]
        float[][] o_;
        [NonSerialized]
        Vector<float>[][][] varrs_;
        [NonSerialized]
        Vector<float>[][][][] varrss_;

        public ScriptOutVal()
        {
            Init();
        }
        [OnDeserialized]
        private void OnDeserialized(StreamingContext context)
        {
            Init();
        }
        void Init()
        {
            eng = IronPython.Hosting.Python.CreateEngine();
            scope = eng.CreateScope();
            o_ = new float[BoxResult.THREADN][];
            varrs_ = new Vector<float>[BoxResult.THREADN][][];
            varrss_ = new Vector<float>[BoxResult.THREADN][][][];
            for (int q = 0; q < varrss_.Length; q++)
            {
                varrs_[q] = new Vector<float>[3][];
                varrss_[q] = new Vector<float>[2][][];
            }
            lasty = new int[BoxResult.THREADN];
            vscope_ = new ScriptScope[BoxResult.THREADN];
        }

        public override bool CanEvaluate()
        {
            scope = eng.CreateScope();
            for (int q = 0; q < Inputs.Length; q++)
            {
                var inp = Inputs[q];
                if (inp == null) continue;
                if (!inp.CanEvaluate()) return false;
                if (q < 3) setVal(scope, q);
                else setCol(scope, q, colMid);
            }
            if (CoreScript.Trim().Length == 0) return false;

            var scr = new StringBuilder();
            scr.Append("try:" + NL);
            scr.Append(indent(CoreScript, 1));
            scr.Append("except:" + NL + " exceptionThrown=True");
            
            var scriptCanEval = eng.CreateScriptSourceFromString(scr.ToString());
            scriptCanEval.Execute(scope);
            
            if (!scope.ContainsVariable("o")) return false;
            foreach (var keyword in keywords)
            {
                if (scope.ContainsVariable(keyword)) return false;
            }

            script = eng.CreateScriptSourceFromString(CoreScript);

            //script for vectors
            var n = GetSize().Width >> MthVector.Shift;
            for (int t = 0; t < lasty.Length; t++)
            {
                resetTh(t, n);
            }
            var vscr = new StringBuilder();
            vscr.Append("for x in range(length):" + NL + " for y in range(vectorN):" + NL);
            for (int q = 0; q < Inputs.Length; q++)
            {
                var inp = Inputs[q];
                if (inp == null) continue;
                var sq = q.ToString();
                if (q < 3)
                {
                    vscr.Append("  i" + sq + "=is" + sq + "[x][y]" + NL);
                }
                else
                {
                    vscr.Append("  i" + sq + "a=is" + sq + "a[x][y]" + NL);
                    vscr.Append("  i" + sq + "r=is" + sq + "r[x][y]" + NL);
                    vscr.Append("  i" + sq + "g=is" + sq + "g[x][y]" + NL);
                    vscr.Append("  i" + sq + "b=is" + sq + "b[x][y]" + NL);
                }
            }
            vscr.Append(indent(CoreScript, 2));
            vscr.Append("  os[x*" + MthVector.Count.ToString() + "+y]=o");
            
            vscript = eng.CreateScriptSourceFromString(vscr.ToString());

            for (int q = 0; q < lasty.Length; q++) lasty[q] = -1;

            return true;
        }
        void resetTh(int th, int n)
        {
            var vscope = eng.CreateScope();
            vscope_[th] = vscope;
            vscope.SetVariable("vectorN", MthVector.Count);
            vscope.SetVariable("length", n);
            var o = new float[n << MthVector.Shift];
            o_[th] = o;
            vscope.SetVariable("os", o);
            for (int q = 0; q < Inputs.Length; q++)
            {
                var inp = Inputs[q];
                if (inp == null) continue;
                var sq = q.ToString();
                if (q < 3)
                {
                    var varrs = new Vector<float>[n];
                    varrs_[th][q] = varrs;
                    vscope.SetVariable("is" + sq, varrs);
                }
                else
                {
                    var mtrx = General.NewMatrix<Vector<float>>(4, n);
                    varrss_[th][q - 3] = mtrx;
                    vscope.SetVariable("is" + sq + "a", mtrx[0]);
                    vscope.SetVariable("is" + sq + "r", mtrx[1]);
                    vscope.SetVariable("is" + sq + "g", mtrx[2]);
                    vscope.SetVariable("is" + sq + "b", mtrx[3]);
                }
            }
        }
        void setVal(ScriptScope scope, int q, float v = 0.5f)
        {
            scope.SetVariable(varNames[q], v);
            //scr.Append("i" + q.ToString() + "=0.5" + NL);
        }
        void setCol(ScriptScope scope, int q, InternalColor col)
        {
            var nams = colNames[q];
            scope.SetVariable(nams[0], col.A);
            scope.SetVariable(nams[1], col.R);
            scope.SetVariable(nams[2], col.G);
            scope.SetVariable(nams[3], col.B);
        }
        string indent(string str, int n)
        {
            var lines = str.Split(sep, StringSplitOptions.None);
            var ind = "";
            for (int q = 0; q < n; q++)
            {
                ind += " ";
            }
            var ret = new StringBuilder(str.Length + lines.Length * n);
            foreach (var line in lines)
            {
                ret.Append(ind + line + NL);
            }
            return ret.ToString();
        }
        public override float Evaluate(Point p)
        {
            for (int q = 0; q < Inputs.Length; q++)
            {
                var inp = Inputs[q];
                if (inp == null) continue;
                if (q < 3) setVal(scope, q, inp.Evaluate(p));
                else setCol(scope, q, inp.EvaluateC(p));
            }

            script.Execute(scope);

            return scope.GetVariable<float>("o");
        }
        
        public override Vector<float> Evaluate(int x, int y, int th)
        {
            if (y != lasty[th])
            {
                lasty[th] = y;
                for (int q = 0; q < Inputs.Length; q++)
                {
                    var inp = Inputs[q];
                    if (inp == null) continue;
                    if (q < 3)
                    {
                        var arr = varrs_[th][q];
                        for (int w = 0; w < arr.Length; w++)
                        {
                            arr[w] = inp.Evaluatev(w * 4, y, th);
                        }
                    }
                    else
                    {
                        var arrs = varrss_[th][q - 3];
                        var arra = arrs[0];
                        var arrr = arrs[1];
                        var arrg = arrs[2];
                        var arrb = arrs[3];
                        for (int w = 0; w < arra.Length; w++)
                        {
                            var vc = inp.EvaluateCv(w * 4, y, th);
                            arra[w] = vc.As;
                            arrr[w] = vc.Rs;
                            arrg[w] = vc.Gs;
                            arrb[w] = vc.Bs;
                        }
                    }
                }
                vscript.Execute(vscope_[th]);
            }
            return new Vector<float>(o_[th], x);
        }
        public override Size GetSize()
        {
            var ret = new Size(int.MaxValue, int.MaxValue);
            for (int q = 0; q < Inputs.Length; q++)
            {
                var inp = Inputs[q];
                if (inp == null) continue;
                var s = inp.GetSize();
                if (s.Width < ret.Width) ret.Width = s.Width;
                if (s.Height < ret.Height) ret.Height = s.Height;
            }
            return ret;
        }
    }
    [Serializable]
    class Tile : Regular1<InternalColor, InternalColor>
    {
        Size siz;

        public override InternalColor EvaluateC(Point p)
        {
            return Inputs[0].EvaluateC(new Point(p.X % siz.Width, p.Y % siz.Height));
        }
        public override VectorColor EvaluateC(int x, int y, int th)
        {
            return Inputs[0].EvaluateC(x % siz.Width, y % siz.Height, th);
        }
        public override Size GetSize()
        {
            siz = Inputs[0].GetSize();
            return new Size(int.MaxValue, int.MaxValue);
        }
    }
}
