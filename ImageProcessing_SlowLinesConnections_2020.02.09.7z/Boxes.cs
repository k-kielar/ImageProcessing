﻿//#define SEQUENTIAL

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.Serialization;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Numerics;
using KKLib;

namespace ImageProcessing
{
    [Serializable]
    abstract class IBox
    {
        public const int PinRadius = 8;
        public const int PinRadiusSq = PinRadius * PinRadius;
        public const int BarHeight = 20;
        public const int ResizeBoxSize = 5;
        public const int CloseBoxSize = 10;
        public const int PinsD = 20;
        public const int PinsMargin = 6;
        public const int PinR = 4;
        public const int PinR2 = PinR * 2;
        public const int InteriorMargin = 6;
        protected static Size TLCorner = new Size(InteriorMargin, BarHeight);

        static Pen penBoxFrame = new Pen(Color.Black);
        static Pen penPin = new Pen(Color.Brown);
        static Brush brBar = new SolidBrush(Color.LightBlue);

        public Rectangle Rect;
        public Pin[][] pins;

        public IBox() { }
        public IBox(Point start, IProcessor proc, int inputsN, int outputsN):this(start,new Size(100, BarHeight + PinsD * (Math.Max(inputsN, outputsN) + 1)), proc, inputsN, outputsN) { }
        public IBox(Point start, Size size, IProcessor proc, int inputsN, int outputsN)
        {
            Rect = new Rectangle(start, size);
            var ins = new Pin[inputsN];
            int y = PinsMargin + BarHeight;
            for (int q = 0; q < ins.Length; q++)
            {
                ins[q] = new Pin(new Point(PinsMargin, y), this, q, proc);
                y += PinsD;
            }
            var outs = new Pin[outputsN];
            y = PinsMargin + BarHeight;
            for (int q = 0; q < outs.Length; q++)
            {
                outs[q] = new Pin(new Point(PinsMargin, y), this, q, proc);
                y += PinsD;
            }
            pins = new Pin[][]
            {
                ins,
                new Pin[]{ new Pin(new Point(Rect.Width - PinsMargin, PinsMargin + BarHeight), this, -1, proc) }
            };
        }

        public Pin GetPin(Point pos)
        {
            foreach (var pinSet in pins)
            {
                foreach (var pin in pinSet)
                {
                    var p = pin.P;
                    int dx = p.X - pos.X;
                    int dy = p.Y - pos.Y;
                    if (dx * dx + dy * dy < PinRadiusSq)
                    {
                        return pin;
                    }
                }
            }
            return null;
        }
        public void Draw(Graphics gr)
        {
            DrawInside(gr);
            gr.DrawRectangle(penBoxFrame, Rect);
            gr.FillRectangle(brBar, Rect.X + 1, Rect.Y + 1, Rect.Width - 1, BarHeight);
            foreach (var pinsset in pins)
            {
                foreach (var pin in pinsset)
                {
                    var p = pin.P;
                    gr.DrawEllipse(penPin, Rect.X + p.X - PinR, Rect.Y + p.Y - PinR, PinR2, PinR2);
                }
            }
        }

        public virtual ActionResult MouseDown(Point pos) { return ActionResult.None; }
        public virtual ActionResult MouseUp(Point pos) { return ActionResult.None; }
        public virtual void MouseMove(Point pos) { }
        public virtual void Close() { }
        protected virtual void DrawInside(Graphics gr) { }

        [OnDeserialized]
        private void OnDeserialized(StreamingContext context)
        {
            foreach (var pinn in pins)
            {
                foreach (var pin in pinn)
                {
                    pin.Box = this;
                }
            }
        }
    }
    abstract class BoxImg : IBox
    {
        protected Bitmap bmp;
        protected Bitmap icon;
        protected float drawWid, drawHei;

        public BoxImg(Point start, Bitmap Bmp)
        {
            Rect = new Rectangle(start, new Size(200, 200));
            bmp = Bmp;

            PrepareIcon();
        }
        protected void PrepareIcon()
        {
            var insideWid = Rect.Width - 2;
            var insideHei = Rect.Height - BarHeight - 1;
            var xratio = (float)insideWid / bmp.Width;
            var yratio = (float)insideHei / bmp.Height;
            if (xratio > yratio)
            {
                float nwid = bmp.Width * yratio;
                icon = new Bitmap((int)(Math.Ceiling(nwid)), insideHei);
                drawWid = nwid;
                drawHei = insideHei;
            }
            else
            {
                float nhei = bmp.Height * xratio;
                icon = new Bitmap(insideWid, (int)(Math.Ceiling(nhei)));
                drawWid = insideWid;
                drawHei = nhei;
            }
        }

        Point mclik;
        public override ActionResult MouseDown(Point pos)
        {
            mclik = pos;
            return ActionResult.Internal;
        }
        public override ActionResult MouseUp(Point pos)
        {
            if (pos == mclik)
            {
                Dispose();
                EasyImgBox.ShowEasy(GetBmp());
                Renew();
            }
            return ActionResult.None;
        }

        protected abstract void UpdateIcon();
        protected abstract void UpdateBlank();
        protected override void DrawInside(Graphics gr)
        {
            gr.DrawImageUnscaled(icon, Rect.X + 1, Rect.Y + BarHeight + 1, Rect.Width - 2, Rect.Height - BarHeight - 1);
        }

        protected abstract void Dispose();
        protected abstract void Renew();
        protected abstract Bitmap GetBmp();

        class EasyImgBox : ImageBox
        {
            public static void ShowEasy(Bitmap bmp)
            {
                var ret = new EasyImgBox(bmp);

                ret.ShowDialog();
            }

            EasyImgBox(Bitmap bmp) : base(bmp)
            {
                picbox.Click += btnok_Click;
            }
        }
    }
    class BoxSource : BoxImg
    {
        ImgSource src;
        Graphics grIco;

        public BoxSource(Point start, Bitmap Bmp) : base(start, Bmp)
        {
            grIco = Graphics.FromImage(icon);
            UpdateIcon();

            src = new ImgSource(Bmp);
            var a = new RawColorToA();
            a.Inputs[0] = src;
            var r = new RawColorToR();
            r.Inputs[0] = src;
            var g = new RawColorToG();
            g.Inputs[0] = src;
            var b = new RawColorToB();
            b.Inputs[0] = src;

            int x = Rect.Width - PinsMargin;
            pins = new Pin[][]
            {
                new Pin[0],
                new Pin[]
                {
                    new Pin(new Point(x, PinsMargin + BarHeight), this, -1, src),
                    new Pin(new Point(x, PinsMargin + BarHeight + PinsD), this, -2, a),
                    new Pin(new Point(x, PinsMargin + BarHeight + 2 * PinsD), this, -3, r),
                    new Pin(new Point(x, PinsMargin + BarHeight + 3 * PinsD), this, -4, g),
                    new Pin(new Point(x, PinsMargin + BarHeight + 4 * PinsD), this, -5, b),
                }
            };
        }

        protected override void UpdateIcon()
        {
            grIco.Clear(Color.White);
            grIco.DrawImage(bmp, 0, 0, drawWid, drawHei);
        }
        protected override void UpdateBlank()
        {
            grIco.Clear(Color.White);
        }
        protected override void Dispose()
        {
            src.Dispose();
        }
        protected override void Renew()
        {
            src.Renew();
        }
        protected override Bitmap GetBmp()
        {
            return src.bmp;
        }
        public override void Close()
        {
            src.Close();
        }
    }
    class BoxResult : BoxImg
    {
#if SEQUENTIAL
        public const int THREADN = 1;
#else
        public const int THREADN = 10;
#endif
        static Brush brSaveIco;
        static Brush brAnalyzer;
        static SaveFileDialog sfd;

        Bitmap blankIco;
        Bitmap mainIco;
        float wk, qk;
        bool justUpdated = true;
        int IconDim = 10;

        static BoxResult()
        {
            brSaveIco = new SolidBrush(Color.Green);
            brAnalyzer = new SolidBrush(Color.Orange);

            sfd = new SaveFileDialog();
            sfd.InitialDirectory = @"D:\Pic\Corrected";
            sfd.Filter = "Png|*.png;";
        }

        public BoxResult(Point start, Bitmap Bmp) : base(start, Bmp)
        {
            blankIco = new Bitmap(icon.Width, icon.Height);
            mainIco = new Bitmap(icon.Width, icon.Height);
            UpdateIcon();

            wk = bmp.Width / (float)icon.Width;
            qk = bmp.Height / (float)icon.Height;
            using (var grico = Graphics.FromImage(blankIco))
            {
                grico.Clear(Color.White);
            }

            pins = new Pin[][]
            {
                new Pin[] { new Pin(new Point(PinsMargin, BarHeight + PinsMargin), this, 0, new ImgResult()) },
                new Pin[0]
            };
        }

        public void UpdateBmpSequential()
        {
            var proc = pins[0][0].Proc.Inputs[0];
            if (proc != null && proc.CanEvaluate())
            {
                PrepareUpdating();
                using (var pxlr = new PixelerVectoric(bmp))
                {
                    UpdateRangeVectoric(pxlr, proc, 0, pxlr.Height, 0);
                    //for (int q = 0; q < pxlr.Height; q++)
                    //{
                    //    for (int w = 0; w < pxlr.Width; w++)
                    //    {
                    //        pxlr.SetPixel(w, q, proc.EvaluateC(new Point(w, q)));
                    //    }
                    //}
                }
                UpdateIcon();
            }
            else
            {
                UpdateBlank();
            }
        }
        public void UpdateBmpParallel()
        {
            var proc = pins[0][0].Proc.Inputs[0];
            if (proc != null && proc.CanEvaluate())
            {
                PrepareUpdating();
                using (var pxlr = new PixelerVectoric(bmp))
                {
                    //var timer = new System.Diagnostics.Stopwatch();
                    //timer.Start();

                    int dq = pxlr.Height / THREADN;
                    var tasks = new Task[THREADN];
                    var tlim = THREADN - 1;
                    for (int l = 0; l < tlim; l++)
                    {
                        var q0 = l * dq;
                        var qlim = q0 + dq;
                        var th = l + 0;
                        var t = new Task(() => UpdateRangeVectoric(pxlr, proc, q0, qlim, th));
                        t.Start();
                        tasks[l] = t;
                    }
                    var tt = new Task(() => UpdateRangeVectoric(pxlr, proc, tlim * dq, pxlr.Height, tlim));
                    tt.Start();
                    tasks[tlim] = tt;
                    Task.WaitAll(tasks);

                    //timer.Stop();
                    //MessageBox.Show(timer.Elapsed.ToString());
                }
                UpdateIcon();
            }
            else
            {
                UpdateBlank();
            }
        }
        void UpdateRange(Pixeler pxlr, IProcessor proc, int q0, int qlim)
        {
            for (int q = q0; q < qlim; q++)
            {
                for (int w = 0; w < pxlr.Width; w++)
                {
                    pxlr.SetPixel(w, q, proc.EvaluateC(new Point(w, q)));
                }
            }
        }

        static readonly Vector<float> ai = new Vector<float>(VectorColor.I * 0x1000000);
        static readonly Vector<float> ak = new Vector<float>(255 * (float)0x1000000 - VectorColor.I * 0x1000000);
        static readonly Vector<float> ri = new Vector<float>(VectorColor.I * 0x10000);
        static readonly Vector<float> rk = new Vector<float>(255 * (float)0x10000 - VectorColor.I * 0x10000);
        static readonly Vector<float> gi = new Vector<float>(VectorColor.I * 256);
        static readonly Vector<float> gk = new Vector<float>(255 * (float)256 - VectorColor.I * 256);
        static readonly Vector<float> bi = new Vector<float>(VectorColor.I);
        static readonly Vector<float> bk = new Vector<float>(255 - VectorColor.I);
        void UpdateRangeVectoric(PixelerVectoric pxlr, IProcessor proc, int q0, int qlim, int th)
        {
            int wlim = (pxlr.Width / VectorColor.Count) * VectorColor.Count;
            for (int q = q0; q < qlim; q++)
            {
                int w = 0;
                for (; w < wlim; w += VectorColor.Count)
                {
                    var vs = proc.EvaluateCv(w, q, th);
                    var va = Vector.ConvertToUInt32(vs.As * ak + ai) & MthVector.MASK_ALPHA;
                    var vr = Vector.ConvertToUInt32(vs.Rs * rk + ri) & MthVector.MASK_RED;
                    var vg = Vector.ConvertToUInt32(vs.Gs * gk + gi) & MthVector.MASK_GREEN;
                    var vb = Vector.ConvertToUInt32(vs.Bs * bk + bi) & MthVector.MASK_BLUE;
                    var vstr = new VecStruct();
                    vstr.vui = va | vr | vg | vb;
                    pxlr.SetVector(w, q, vstr.v4);
                }
                for (; w < pxlr.Width; w++)
                {
                    pxlr.SetPixel(w, q, proc.EvaluateC(new Point(w, q)));
                }
            }
        }
        void UpdateRangeVectoricOld(Pixeler pxlr, IProcessor proc, int q0, int qlim, int th)
        {
            int wlim = (pxlr.Width / VectorColor.Count) * VectorColor.Count;
            for (int q = q0; q < qlim; q++)
            {
                int w = 0;
                for (; w < wlim; w += VectorColor.Count)
                {
                    var vs = proc.EvaluateCv(w, q, th);
                    vs.RescaleToByte();
                    for (int t = 0; t < VectorColor.Count; t++)
                    {
                        pxlr.SetPixel(w + t, q, new RawColor((byte)vs.As[t], (byte)vs.Rs[t], (byte)vs.Gs[t], (byte)vs.Bs[t]));
                    }
                }
                for (; w < pxlr.Width; w++)
                {
                    pxlr.SetPixel(w, q, proc.EvaluateC(new Point(w, q)));
                }
            }
        }

        public void Update()
        {
            var proc = pins[0][0].Proc.Inputs[0];
            if (proc != null && proc.CanEvaluate())
            {
                PrepareUpdating();
                using (var pxlr = new Pixeler(mainIco))
                {
                    for (int q = 0; q < pxlr.Height; q++)
                    {
                        for (int w = 0; w < pxlr.Width; w++)
                        {
                            pxlr.SetPixel(w, q, proc.EvaluateC(new Point((int)(w * wk), (int)(q * qk))));
                        }
                    }
                }
                UpdateIcon();
                justUpdated = true;
            }
            else
            {
                UpdateBlank();
            }
        }
        void PrepareUpdating()
        {
            var s = pins[0][0].Proc.GetSize();
            if (s.Width == int.MaxValue || s.Height == int.MaxValue) return;
            if (s != bmp.Size)
            {
                bmp.Dispose();
                bmp = new Bitmap(s.Width, s.Height);
                PrepareIcon();
                mainIco = new Bitmap(icon.Width, icon.Height);
                UpdateIcon();
                wk = bmp.Width / (float)icon.Width;
                qk = bmp.Height / (float)icon.Height;
            }
        }

        public void Save(string path)
        {
            bmp.Save(path);
        }
        
        protected override void UpdateIcon()
        {
            icon = mainIco;
        }
        protected override void UpdateBlank()
        {
            icon = blankIco;
        }
        protected override void Dispose()
        {

        }
        protected override void Renew()
        {

        }
        protected override Bitmap GetBmp()
        {
            if (justUpdated)
            {
#if SEQUENTIAL
                UpdateBmpSequential();
#else
                UpdateBmpParallel();
#endif

                justUpdated = false;
            }
            return bmp;
        }
        public override void Close()
        {
            bmp.Dispose();
            bmp = null;
        }

        int btnDwnIndx = int.MaxValue;
        public override ActionResult MouseDown(Point pos)
        {
            if (pos.Y > Rect.Height - IconDim)
            {
                btnDwnIndx = pos.X / IconDim;
                return ActionResult.Internal;
            }
            else
            {
                btnDwnIndx = int.MaxValue;
                return base.MouseDown(pos);
            }
        }
        public override ActionResult MouseUp(Point pos)
        {
            var ret = ActionResult.None;
            if (btnDwnIndx < 2 && pos.Y > Rect.Height - IconDim && pos.X / IconDim < 2)
            {
                switch (btnDwnIndx)
                {
                    case 0:
                        if (sfd.ShowDialog() == DialogResult.OK)
                        {
                            Save(sfd.FileName);
                        }
                        break;
                    case 1:
                        ShowAnalyzer();
                        break;
                    default:
                        break;
                }
                ret = ActionResult.Internal;
            }
            btnDwnIndx = int.MaxValue;
            if (ret == ActionResult.None) return base.MouseUp(pos);
            else return ret;
        }
        protected override void DrawInside(Graphics gr)
        {
            base.DrawInside(gr);
            gr.FillRectangle(brSaveIco, Rect.X, Rect.Y + Rect.Height - IconDim, IconDim, IconDim);
            gr.FillRectangle(brAnalyzer, Rect.X + IconDim, Rect.Y + Rect.Height - IconDim, IconDim, IconDim);
        }

        void ShowAnalyzer()
        {
            var frm = new ImgAnalyzeForm();
            frm.SetBmp(bmp);
            frm.Show();
        }
    }
    [Serializable]
    class BoxRegular : IBox
    {
        public BoxRegular(Point start, IProcessor proc, int inputsN) : this(start, new Size(100, BarHeight + PinsD * (inputsN + 1)), proc, inputsN) { }
        public BoxRegular(Point start, Size size, IProcessor proc, int inputsN)
        {
            Rect = new Rectangle(start, size);
            var ins = new Pin[inputsN];
            int y = PinsMargin + BarHeight;
            for (int q = 0; q < ins.Length; q++)
            {
                ins[q] = new Pin(new Point(PinsMargin, y), this, q, proc);
                y += PinsD;
            }
            pins = new Pin[][]
            {
                ins,
                new Pin[]{ new Pin(new Point(Rect.Width - PinsMargin, PinsMargin + BarHeight), this, -1, proc) }
            };
        }
    }
    [Serializable]
    class BoxAdjust : BoxRegular
    {
        static Size TLCorner = new Size(InteriorMargin, BarHeight);
        static int dotR = 3;
        static int dotD = dotR * 2;
        Adjust Proc;
        int Width;
        int Height;
        static Brush br = new SolidBrush(Color.Black);

        public BoxAdjust(Point start, Adjust proc) : base(start, new Size(200, 200), proc, 1)
        {
            Proc = proc;
            Width = Rect.Width - 2 * InteriorMargin;
            Height = Rect.Height - InteriorMargin - BarHeight;
        }

        Point mclick;
        public override ActionResult MouseDown(Point pos)
        {
            mclick = pos - TLCorner;
            return ActionResult.Internal;
        }
        public override void MouseMove(Point pos)
        {
            var p = pos - TLCorner;
            if (p.X >= 0 && p.Y >= 0 && p.X < Width && p.Y <= Height)
            {
                int i = p.X * Proc.vs.Length / Width;
                Proc.Set(1 - (p.Y / (float)Height), i);
            }
        }
        protected override void DrawInside(Graphics gr)
        {
            var vs = Proc.vs;
            float xstep = (float)Width / vs.Length;
            float x = xstep * 0.5f - dotR;
            for (int q = 0; q < vs.Length; q++)
            {
                var v = vs[q];
                int y = (int)((1 - v) * Height);
                gr.FillEllipse(br, Rect.X + InteriorMargin + (int)x, Rect.Y + BarHeight + y, dotD, dotD);
                x += xstep;
            }
        }
        public override ActionResult MouseUp(Point pos)
        {
            return ActionResult.Execute;
        }
    }
    [Serializable]
    class BoxValue : BoxRegular
    {
        static int dotR = 3;
        static int dotD = dotR * 2;
        Value Proc;
        int Width;
        int Height;
        float k;
        static Brush br = new SolidBrush(Color.Black);

        public BoxValue(Point start, Value proc, float K = 1) : base(start, new Size(200, BarHeight + PinsD+InteriorMargin), proc, 0)
        {
            Proc = proc;
            Width = Rect.Width - 2 * InteriorMargin;
            Height = Rect.Height - InteriorMargin - BarHeight;
            k = K;
        }

        public override ActionResult MouseDown(Point pos)
        {
            return ActionResult.Internal;
        }
        public override void MouseMove(Point pos)
        {
            var p = pos - TLCorner;
            if (p.X >= 0 && p.Y >= 0 && p.X < Width && p.Y <= Height)
            {
                Proc.V = p.X * k / Width;
            }
        }
        protected override void DrawInside(Graphics gr)
        {
            gr.FillEllipse(br, Rect.X + InteriorMargin + (int)(Proc.V / k * Width), Rect.Y + BarHeight + (PinsD >> 1), dotD, dotD);
        }
        public override ActionResult MouseUp(Point pos)
        {
            return ActionResult.Execute;
        }
    }
    [Serializable]
    class BoxColor : BoxRegular
    {
        SingleColor Proc;
        Rectangle interior;
        [NonSerialized]
        ColorPickerDialog dialog;
        [NonSerialized]
        Form1 frm;

        public BoxColor(Point start, SingleColor proc, Form1 form) : base(start, new Size(50, BarHeight + 50), proc, 0)
        {
            Proc = proc;
            interior = new Rectangle(InteriorMargin, InteriorMargin + BarHeight, Rect.Width - 2 * InteriorMargin, Rect.Height - InteriorMargin - BarHeight);
            dialog = new ColorPickerDialog();
            dialog.StartPosition = FormStartPosition.Manual;
            frm = form;
        }

        [OnDeserialized]
        private void OnDeserialized(StreamingContext context)
        {
            dialog = new ColorPickerDialog();
            dialog.StartPosition = FormStartPosition.Manual;
            frm = Form1.Frm;
        }

        protected override void DrawInside(Graphics gr)
        {
            var nrect = interior;
            nrect.Location += (Size)Rect.Location;
            using (var br = new SolidBrush(((RawColor)(Proc.V)).ColorV))
            {
                gr.FillRectangle(br, nrect);
            }
        }
        public override ActionResult MouseDown(Point pos)
        {
            return ActionResult.Internal;
        }
        public override ActionResult MouseUp(Point pos)
        {
            dialog.Value = Proc.V;
            var p = frm.PointToScreen(Rect.Location);
            p.X -= dialog.Width / 2;
            p.Y -= dialog.Height / 2;
            if (p.X < 0) p.X = 0;
            if (p.Y < 0) p.Y = 0;
            dialog.Location = p;

            var res = dialog.ShowDialog();
            if (res == DialogResult.OK)
            {
                Proc.V = dialog.Value;
                return ActionResult.Execute;
            }
            else return ActionResult.None;
        }
    }
    [Serializable]
    class BoxColToARGB : IBox
    {
        public BoxColToARGB(Point start)
        {
            Rect = new Rectangle(start, new Size(100, BarHeight + PinsD * 4));
            init();
        }
        void init()
        {
            var rgb = new RawColorHolder();

            var a = new RawColorToA();
            a.Inputs[0] = rgb;
            var r = new RawColorToR();
            r.Inputs[0] = rgb;
            var g = new RawColorToG();
            g.Inputs[0] = rgb;
            var b = new RawColorToB();
            b.Inputs[0] = rgb;

            pins = new Pin[][]
            {
                new Pin[] { new Pin(new Point(PinsMargin, PinsMargin + BarHeight), this, 0, rgb) },
                new Pin[]
                {
                    new Pin(new Point(Rect.Width - PinsMargin, PinsMargin + BarHeight), this, -1, a),
                    new Pin(new Point(Rect.Width - PinsMargin, PinsMargin + BarHeight+PinsD), this, -2, r),
                    new Pin(new Point(Rect.Width - PinsMargin, PinsMargin + BarHeight+PinsD*2), this, -3, g),
                    new Pin(new Point(Rect.Width - PinsMargin, PinsMargin + BarHeight+PinsD*3), this, -4, b),
                }
            };
        }

        [OnDeserialized]
        private void OnDeserialized(StreamingContext context)
        {
            init();
        }
    }
    [Serializable]
    class BoxRGBToHSB : IBox
    {
        public BoxRGBToHSB(Point start)
        {
            Rect = new Rectangle(start, new Size(100, BarHeight + PinsD * 4));
            init();
        }
        void init()
        {
            var rgb = new RawColorHolder();
            var h = new RawColorToHue();
            h.Inputs[0] = rgb;
            var s = new RawColorToSaturation();
            s.Inputs[0] = rgb;
            var b = new RawColorToBrightness();
            b.Inputs[0] = rgb;

            pins = new Pin[][]
            {
                new Pin[] { new Pin(new Point(PinsMargin, PinsMargin + BarHeight), this, 0, rgb) },
                new Pin[]
                {
                    new Pin(new Point(Rect.Width - PinsMargin, PinsMargin + BarHeight), this, -1, h),
                    new Pin(new Point(Rect.Width - PinsMargin, PinsMargin + BarHeight+PinsD), this, -2, s),
                    new Pin(new Point(Rect.Width - PinsMargin, PinsMargin + BarHeight+PinsD*2), this, -3, b),
                }
            };
        }

        [OnDeserialized]
        private void OnDeserialized(StreamingContext context)
        {
            init();
        }
    }
    [Serializable]
    class BoxRGBToHCB : IBox
    {
        public BoxRGBToHCB(Point start)
        {
            Rect = new Rectangle(start, new Size(100, BarHeight + PinsD * 4));
            init();
        }
        void init()
        {
            var rgb = new RawColorHolder();
            var h = new RawColorToHue();
            h.Inputs[0] = rgb;
            var c = new RawColorToColorful();
            c.Inputs[0] = rgb;
            var b = new RawColorToBrightness();
            b.Inputs[0] = rgb;

            pins = new Pin[][]
            {
                new Pin[] { new Pin(new Point(PinsMargin, PinsMargin + BarHeight), this, 0, rgb) },
                new Pin[]
                {
                    new Pin(new Point(Rect.Width - PinsMargin, PinsMargin + BarHeight), this, -1, h),
                    new Pin(new Point(Rect.Width - PinsMargin, PinsMargin + BarHeight+PinsD), this, -2, c),
                    new Pin(new Point(Rect.Width - PinsMargin, PinsMargin + BarHeight+PinsD*2), this, -3, b),
                }
            };
        }

        [OnDeserialized]
        private void OnDeserialized(StreamingContext context)
        {
            init();
        }
    }
    [Serializable]
    class BoxScript : BoxRegular
    {
        [NonSerialized]
        ScriptForm form;

        public BoxScript(Point start, ScriptOutVal proc) : base(start, proc, 5)
        {
            form = new ScriptForm(proc);
        }

        public override ActionResult MouseDown(Point pos)
        {
            return ActionResult.Internal;
        }
        public override ActionResult MouseUp(Point pos)
        {
            form.Show();

            return ActionResult.None;
        }

        [OnDeserialized]
        private void OnDeserialized(StreamingContext context)
        {
            form = new ScriptForm(pins[0][0].Proc as ScriptOutVal);
        }
    }
}
